package com.cts.controller;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.User;
@RestController
public class UserController {

    @GetMapping(
        value = "/user",
        produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE }
    )
    public User getUser() {
        return new User(1, "Shekhar");
    }
}
