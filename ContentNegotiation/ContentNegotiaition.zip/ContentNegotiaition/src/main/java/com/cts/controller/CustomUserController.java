package com.cts.controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.User;

@RestController
public class CustomUserController {
	/**
	 * 
       application	It's an application data (not audio/video)
       vnd	        Short for vendor (means it's custom, not standard)
       mycompany	Your company or app name
       user	        The resource type you are working with (here: "User")
       v1	        The version of the resource or API (version 1)
       +json	    The format of the data (JSON in this case)
	 * 
	 */
//http://localhost:2025/custom-user
    @GetMapping(
        value = "/custom-user",
        produces = "application/vnd.cts.user.v1+json"
    )
    public User getCustomUser() {
        return new User(1, "Shekhar Custom");
    }
}
