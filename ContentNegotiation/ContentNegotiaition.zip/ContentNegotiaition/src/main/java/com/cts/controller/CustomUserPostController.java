package com.cts.controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cts.model.User;

@RestController
public class CustomUserPostController {
//Different versions of the API can coexist without changing the URL.
	
	/**
	 * application/vnd.mycompany.user.v1+json	Get user version 1
     *application/vnd.mycompany.user.v2+json	Get user version 2
	 * 
	 */
    @PostMapping(
        value = "/custom-user",
        consumes = "application/vnd.cts.user.v1+json"
    )
    public String createCustomUser(@RequestBody User user) {
        return "Received user: " + user.getName();
    }
}
