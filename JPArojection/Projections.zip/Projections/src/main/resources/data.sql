-- Insert Authors
INSERT INTO author (id, first_name, last_name) VALUES (1, 'Chetan', 'Bhagat');
INSERT INTO author (id, first_name, last_name) VALUES (2, 'Arundhati', 'Roy');
INSERT INTO author (id, first_name, last_name) VALUES (3, 'R. K.', 'Narayan');
INSERT INTO author (id, first_name, last_name) VALUES (4, 'Amish', 'Tripathi');

-- Insert Libraries
INSERT INTO library (id, library_name, city) VALUES (1, 'Delhi Public Library', 'New Delhi');
INSERT INTO library (id, library_name, city) VALUES (2, 'Asiatic Library', 'Mumbai');

-- Insert Books
INSERT INTO book (id, title, published_year, author_id, library_id) VALUES (1, 'Five Point Someone', 2004, 1, 1);
INSERT INTO book (id, title, published_year, author_id, library_id) VALUES (2, 'The God of Small Things', 1997, 2, 1);
INSERT INTO book (id, title, published_year, author_id, library_id) VALUES (3, 'Malgudi Days', 1943, 3, 2);
INSERT INTO book (id, title, published_year, author_id, library_id) VALUES (4, 'The Immortals of Meluha', 2010, 4, 2);
