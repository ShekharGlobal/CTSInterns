package com.cts.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.dto.BookLibraryDTO;
import com.cts.projections.BookTitleAndAuthorProjection;
import com.cts.projections.BookWithAuthorFullNameProjection;
import com.cts.service.BookService;
/**
 *  Browser/Postman
         ↓
 *  Controller (BookController)
         ↓
 *  Service (BookService)
         ↓
 *  Repository (BookRepository)
         ↓
 *  Database (H2/MySQL/PostgreSQL)

 */
@RestController
@RequestMapping("/books")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    //http://localhost:2025/books/titles-authors
    @GetMapping("/titles-authors")
    public List<BookTitleAndAuthorProjection> getTitlesAndAuthors() {
        return bookService.getTitlesAndAuthors();
    }

    //http://localhost:2025/books/library-info
    @GetMapping("/library-info")
    public List<BookLibraryDTO> getBookLibraryInfo() {
        return bookService.getBookLibraryInfo();
    }
    //http://localhost:2025/books/author-fullname
    @GetMapping("/author-fullname")
    public List<BookWithAuthorFullNameProjection> getBooksWithAuthorFullName() {
        return bookService.getBooksWithAuthorFullName();
    }
}
