package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cts.dto.BookLibraryDTO;
import com.cts.entity.Book;
import com.cts.projections.BookTitleAndAuthorProjection;
import com.cts.projections.BookWithAuthorFullNameProjection;

public interface BookRepository extends JpaRepository<Book, Long> {

    // Interface-based Projection
    List<BookTitleAndAuthorProjection> findByPublishedYearGreaterThan(int year);

    // DTO (Class-based) Projection
    @Query("SELECT new com.cts.dto.BookLibraryDTO(b.title, b.library.city, new com.cts.dto.AuthorDTO(a.firstName, a.lastName)) " +
    	       "FROM Book b JOIN b.author a")
    	List<BookLibraryDTO> findAllBookLibraryInfo();

    
    @Query("SELECT b FROM Book b JOIN b.author a")
    List<BookWithAuthorFullNameProjection> findAllWithAuthorFullName();
}


