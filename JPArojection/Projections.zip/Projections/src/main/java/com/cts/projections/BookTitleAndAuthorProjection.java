package com.cts.projections;

public interface BookTitleAndAuthorProjection {
    String getTitle();

    AuthorInfo getAuthor();

    interface AuthorInfo {
        String getFirstName();
        String getLastName();
    }
}
