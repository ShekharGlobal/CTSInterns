package com.cts.dto;

public class BookLibraryDTO {
    private String title;
    private String city;
    private AuthorDTO author;

    public BookLibraryDTO(String title, String city, AuthorDTO author) {
        this.title = title;
        this.city = city;
        this.author = author;
    }

 
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public AuthorDTO getAuthor() {
        return author;
    }

    public void setAuthor(AuthorDTO author) {
        this.author = author;
    }
}
