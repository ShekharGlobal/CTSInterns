package com.cts.projections;



import org.springframework.beans.factory.annotation.Value;

public interface BookWithAuthorFullNameProjection {

    String getTitle();

    // Using SpEL (Spring Expression Language) to combine first and last name
    @Value("#{target.authorFirstName + ' ' + target.authorLastName}")
    String getAuthorFullName();
}
