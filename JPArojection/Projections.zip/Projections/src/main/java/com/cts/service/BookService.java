package com.cts.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cts.dto.BookLibraryDTO;
import com.cts.projections.BookTitleAndAuthorProjection;
import com.cts.projections.BookWithAuthorFullNameProjection;
import com.cts.repository.BookRepository;

@Service
public class BookService {

    private final BookRepository bookRepository;

    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public List<BookTitleAndAuthorProjection> getTitlesAndAuthors() {
        return bookRepository.findByPublishedYearGreaterThan(2000);
    }

    public List<BookLibraryDTO> getBookLibraryInfo() {
        return bookRepository.findAllBookLibraryInfo();
    }

    public List<BookWithAuthorFullNameProjection> getBooksWithAuthorFullName() {
        return bookRepository.findAllWithAuthorFullName();
    }
}
