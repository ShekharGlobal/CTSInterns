package com.cts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;

import com.cts.bean.Employee;
import com.cts.dao.EmployeeDAO;

@SpringBootApplication
@EnableJpaAuditing
public class SpringdatajpaApplication implements CommandLineRunner {

    @Autowired
    private EmployeeDAO employeeDAO;

    public static void main(String[] args) {
        SpringApplication.run(SpringdatajpaApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        Employee e1 = new Employee();
        e1.setEmpId("E1");
        e1.setEmpName("Vijay");
        e1.setDepartment("IT");
        e1.setSalary(50000);

        Employee e2 = new Employee();
        e2.setEmpId("E2");
        e2.setEmpName("David");
        e2.setDepartment("HR");
        e2.setSalary(40000);

        Employee e3 = new Employee();
        e3.setEmpId("E3");
        e3.setEmpName("Ravi");
        e3.setDepartment("IT");
        e3.setSalary(60000);

        Employee e4 = new Employee();
        e4.setEmpId("E4");
        e4.setEmpName("Manoj");
        e4.setDepartment("Finance");
        e4.setSalary(45000);

        employeeDAO.addEmployee(e1);
        employeeDAO.addEmployee(e2);
        employeeDAO.addEmployee(e3);
        employeeDAO.addEmployee(e4);

        System.out.println("----- All Employees -----");
        List<Employee> list = employeeDAO.getAllEmployees();

        for (Employee emp : list) {
            System.out.println(emp.getEmpName() + " - " + emp.getDepartment());
        }

        System.out.println("\n----- Pagination Example -----");

        Page<Employee> page = employeeDAO.getEmployeesByPage(0, 2);

        System.out.println("Total Pages: " + page.getTotalPages());
        System.out.println("Total Records: " + page.getTotalElements());

        page.getContent().forEach(emp ->
                System.out.println(emp.getEmpName()));

        System.out.println("\n----- Sorting by Salary -----");

        List<Employee> sortedList = employeeDAO.getEmployeesSortedBySalary();

        sortedList.forEach(emp ->
                System.out.println(emp.getEmpName() + " - " + emp.getSalary()));

        System.out.println("\n----- Pagination + Sorting -----");

        Page<Employee> sortedPage = employeeDAO.getEmployeesPageSorted(0, 3);

        sortedPage.getContent().forEach(emp ->
                System.out.println(emp.getEmpName() + " - " + emp.getSalary()));
    }
}