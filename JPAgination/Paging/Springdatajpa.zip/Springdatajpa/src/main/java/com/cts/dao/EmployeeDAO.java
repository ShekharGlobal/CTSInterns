package com.cts.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.cts.bean.Employee;
import com.cts.repository.EmployeeRepository;

@Repository
public class EmployeeDAO {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Insert Employee
    public void addEmployee(Employee employee) {
        employeeRepository.save(employee);
    }

    // Get All Employees
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    // Pagination
    public Page<Employee> getEmployeesByPage(int pageNumber, int pageSize) {

        Pageable pageable = PageRequest.of(pageNumber, pageSize);

        return employeeRepository.findAll(pageable);
    }

    // Sorting
    public List<Employee> getEmployeesSortedBySalary() {

        return employeeRepository.findAll(
                Sort.by(Sort.Direction.ASC, "salary"));
    }

    // Pagination + Sorting
    public Page<Employee> getEmployeesPageSorted(int page, int size) {

        Pageable pageable = PageRequest.of(
                page,
                size,
                Sort.by("salary").descending()
        );

        return employeeRepository.findAll(pageable);
    }
}