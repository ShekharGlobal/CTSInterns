package com.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.util.EmployeeDAO;
import com.exception.AddressUpdateException;

@ExtendWith(MockitoExtension.class)
public class EmployeeDAOTest {

	// Mock dependencies
	@Mock
	private DataSource ds;

	@Mock
	private Connection connection;

	@Mock
	private PreparedStatement preparedStatement;

	// Inject mocks into DAO under test
	@InjectMocks
	private EmployeeDAO employeeDAO;
/**
 * Mock = Fake object
   Stub = Fake method response/A predefined return value for a method call
 * Spy → Real object with optional stubbing.
 * Verify → Checks if interaction happened.
 */
	// Lenient stubbing setup
	/**
	 * Normally, Mockito throws an error if:

A stubbed method is never used in a test.
	 * @throws SQLException
	 */
	@BeforeEach
	public void setUp() throws SQLException {
		lenient().when(ds.getConnection()).thenReturn(connection);
		lenient().when(connection.prepareStatement(anyString())).thenReturn(preparedStatement);
		lenient().when(preparedStatement.executeUpdate()).thenReturn(1);
	}

	@Test
	public void testInvalidEmployeeId() {
		// employeeId length not equal to 5 should throw AddressUpdateException
		//This test throws exception before DB is called.
		AddressUpdateException ex = assertThrows(AddressUpdateException.class,
				() -> employeeDAO.addressChange("1234", "Some Valid Address"));
		assertEquals("Invalid Employee Id", ex.getMessage());
	}

	@Test
	public void testInvalidEmployeeAddress() {
		// employeeAddress is null should throw AddressUpdateException
		AddressUpdateException ex = assertThrows(AddressUpdateException.class,
				() -> employeeDAO.addressChange("12345", null));
		assertEquals("Invalid Employee Address", ex.getMessage());
	}
/**
 * assertThrows(AddressUpdateException.class, new Executable() {
 *  @Override
 *  public void execute() throws Throwable {
 *  employeeDAO.addressChange(null, "Some Valid Address");
 *  }
 *  });
 */
	@Test
	public void testInvalidEmployeeIdWithNull() {
		// employeeId is null should throw AddressUpdateException
		AddressUpdateException ex = assertThrows(AddressUpdateException.class,
				() -> employeeDAO.addressChange(null, "Some Valid Address"));
		assertEquals("Invalid Employee Id", ex.getMessage());
	}

	@Test
	public void testMethodCall() throws SQLException, AddressUpdateException {
		// Valid inputs should return true
		boolean result = employeeDAO.addressChange("12345", "Updated Address");
		assertTrue(result);

		// Verify required interactions exactly one time
		verify(ds, times(1)).getConnection();
		verify(connection, times(1)).prepareStatement(anyString());
		verify(preparedStatement, times(1)).executeUpdate();

		// Do NOT assert no-more-interactions; DAO may call setString/close, etc.
	}
}