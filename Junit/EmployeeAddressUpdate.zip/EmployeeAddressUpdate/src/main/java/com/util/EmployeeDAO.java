package com.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.DataSource;

import com.exception.AddressUpdateException;

public class EmployeeDAO {
	
	private DataSource ds;
	

	public EmployeeDAO(DataSource ds) {
		super();
		this.ds = ds;
	}
	
	
	 public  boolean addressChange(String employeeId, String employeeAddress) throws AddressUpdateException {
		try {
			if(employeeId == null || employeeId.length()!=5) {
				throw new AddressUpdateException("Invalid Employee Id");
			}
			
			if(employeeAddress==null) {
				throw new AddressUpdateException("Invalid Employee Address");
			}
			
			Connection con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE EmployeeDetails SET employeeAddress = employeeAddress + ? WHERE employeeId = ?");
			ps.setString(1, employeeAddress);
			ps.setString(2, employeeId);
			int result = ps.executeUpdate();
			return result > 0;
		}catch(SQLException ex) {
			throw new AddressUpdateException(ex.getMessage());
		}
	 }
		
	
}
