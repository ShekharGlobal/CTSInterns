package com.cts.mockito;

import static org.mockito.Mockito.*;
import org.junit.Test;
import static org.junit.Assert.*;
import java.util.List;

public class MockitoExample {

	@Test
	public void testMockingAndStubbing() {
		// Creating a mock List
		List<String> mockList = mock(List.class);

		// Defining behavior
		when(mockList.get(0)).thenReturn("Hello Mockito!");

		// Using mock
		assertEquals("Hello Mockito!", mockList.get(0));

		// Verifying interaction
		verify(mockList).get(0);
	}

	@Test
	public void testArgumentMatching() {
		// Create a mock List
		List<String> mockList = mock(List.class);

		// Stub the get method for any integer argument
		when(mockList.get(anyInt())).thenReturn("Matched!");

		// Use the mock object
		String result = mockList.get(5); // Argument 5 matches 'anyInt()'

		// Verify the result
		assertEquals("Matched!", result);

		// Verify that the get method was called with the argument 5
		verify(mockList).get(5);
	}

	@Test
	public void testHandlingVoidMethod() {
		List<String> mockList = mock(List.class);

		// Stub the clear method to do nothing
		doNothing().when(mockList).clear();

		// Use the mock object
		mockList.clear();

		// Verify that the clear method was called once
		verify(mockList, times(1)).clear();
	}
}
