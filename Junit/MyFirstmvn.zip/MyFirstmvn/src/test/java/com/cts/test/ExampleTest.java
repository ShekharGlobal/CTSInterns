package com.cts.test;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

class ExampleTest {

    @BeforeAll
    static void setupAll() {
        System.out.println("Runs once before all tests.");
    }

    @BeforeEach
    void setup() {
        System.out.println("Runs before each test.");
    }

    @Test
    void testOne() {
        assertTrue(5 > 2);
    }

    @Test
    void testTwo() {
        assertEquals("Hello", "Hello");
    }

    @AfterEach
    void teardown() {
        System.out.println("Runs after each test.");
    }

    @AfterAll
    static void teardownAll() {
        System.out.println("Runs once after all tests.");
    }
}
