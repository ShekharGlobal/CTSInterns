package com.user.proxy;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PathVariable;
  
@FeignClient(name="ProductApp",url="http://localhost:8091/")
public interface ServiceProxy {
	

	   @GetMapping(value="/getInfo")
		public String getDetails(); 
	   
	   
	   @GetMapping("{id}")
	    String getProductDetails(@PathVariable("id") Long id);
	   

}