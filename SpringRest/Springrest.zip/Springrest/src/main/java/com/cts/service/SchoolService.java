package com.cts.service;

import java.util.List;

import com.cts.bean.School;
import com.cts.bean.Student;

public interface SchoolService {

    void addSchool(School school);

    void registerStudentToSchool(String schoolId, List<Student> students);

    List<School> schoolWithMaximumStudents(String city);
}