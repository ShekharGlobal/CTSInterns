package com.cts.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bean.School;
import com.cts.bean.Student;
import com.cts.repository.SchoolRepository;
import com.cts.repository.StudentRepository;

@Service
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    private SchoolRepository schoolRepo;

    @Autowired
    private StudentRepository studentRepo;

    @Override
    public void addSchool(School school) {
        schoolRepo.save(school);
    }

    @Override
    public void registerStudentToSchool(String schoolId, List<Student> students) {

        Optional<School> schoolOpt = schoolRepo.findById(schoolId);

        if (schoolOpt.isPresent()) {

            School school = schoolOpt.get();

            for (Student student : students) {
                student.setSchool(school);
            }

            studentRepo.saveAll(students);
        }
    }

    @Override
    public List<School> schoolWithMaximumStudents(String city) {

        return schoolRepo.findSchoolWithMaxStudentsInCity(city);
    }
}