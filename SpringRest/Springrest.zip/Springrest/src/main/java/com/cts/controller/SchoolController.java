package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bean.School;
import com.cts.bean.Student;
import com.cts.service.SchoolService;

@RestController
@RequestMapping("/school")
public class SchoolController {

    @Autowired
    private SchoolService schoolService;

    // Add School
    @PostMapping("/add")
    public String addSchool(@RequestBody School school) {

        schoolService.addSchool(school);

        return "School Added Successfully";
    }

    // Register students to school
    @PostMapping("/register/{schoolId}")
    public String registerStudents(@PathVariable String schoolId,
                                   @RequestBody List<Student> students) {

        schoolService.registerStudentToSchool(schoolId, students);

        return "Students Registered Successfully";
    }

    // Get school with maximum students
    @GetMapping("/max/{city}")
    public List<School> getSchoolWithMaxStudents(@PathVariable String city) {

        return schoolService.schoolWithMaximumStudents(city);
    }
}