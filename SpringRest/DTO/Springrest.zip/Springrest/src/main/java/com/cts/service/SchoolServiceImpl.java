package com.cts.service;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.bean.School;
import com.cts.bean.Student;
import com.cts.dto.SchoolDTO;
import com.cts.dto.StudentDTO;
import com.cts.repository.SchoolRepository;
import com.cts.repository.StudentRepository;

@Service
public class SchoolServiceImpl implements SchoolService {

    @Autowired
    private SchoolRepository schoolRepo;

    @Autowired
    private StudentRepository studentRepo;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public void addSchool(SchoolDTO schoolDTO) {

        School school = modelMapper.map(schoolDTO, School.class);

        schoolRepo.save(school);
    }

    @Override
    public void registerStudentToSchool(Long schoolId, List<StudentDTO> students) {

        School school = schoolRepo.findById(schoolId).orElse(null);

        List<Student> studentEntities = students.stream()
                .map(dto -> modelMapper.map(dto, Student.class))
                .collect(Collectors.toList());

        for (Student s : studentEntities) {
            s.setSchool(school);
        }

        studentRepo.saveAll(studentEntities);
    }

    @Override
    public List<SchoolDTO> schoolWithMaximumStudents(String city) {

        List<School> schools = schoolRepo.findSchoolWithMaxStudentsInCity(city);

        return schools.stream()
                .map(school -> modelMapper.map(school, SchoolDTO.class))
                .collect(Collectors.toList());
    }
}