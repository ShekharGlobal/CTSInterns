package com.cts.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.dto.SchoolDTO;
import com.cts.dto.StudentDTO;
import com.cts.service.SchoolService;

@RestController
@RequestMapping("/school")
public class SchoolController {

    @Autowired
    private SchoolService schoolService;

    @PostMapping("/add")
    public String addSchool(@RequestBody SchoolDTO schoolDTO) {

        schoolService.addSchool(schoolDTO);

        return "School Added";
    }

    @PostMapping("/register/{schoolId}")
    public String registerStudents(@PathVariable Long schoolId,
                                   @RequestBody List<StudentDTO> students) {

        schoolService.registerStudentToSchool(schoolId, students);

        return "Students Registered";
    }

    @GetMapping("/max/{city}")
    public List<SchoolDTO> getSchoolMaxStudents(@PathVariable String city){

        return schoolService.schoolWithMaximumStudents(city);
    }
}