import { Component } from '@angular/core';

@Component({
  selector: 'app-one-way',
  standalone: true,
  imports: [],
  templateUrl: './one-way.html',
  styleUrl: './one-way.css',
})
export class OneWay {
  title = 'One Way Data Binding Example';
  username = 'Angular Student';
}
