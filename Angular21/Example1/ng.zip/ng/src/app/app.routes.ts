import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'one-way',
    loadComponent: () =>
      import('./data-binding/one-way/one-way')
        .then(m => m.OneWay),
  },
  {
    path: 'two-way',
    loadComponent: () =>
      import('./data-binding/two-way/two-way')
        .then(m => m.TwoWay),
  },
  {
    path: 'image',
    loadComponent: () =>
      import('./data-binding/property/property')
        .then(m => m.Property),
  }
];
