import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { DecimalPipe } from '@angular/common'; // Import only what you need
import { CountriesService } from '../../service/countries';

@Component({
  selector: 'app-countries',
  imports: [DecimalPipe],
  templateUrl: './countries.html',
})
export class CountriesComponent {
  private countriesService = inject(CountriesService); // Modern injection

  // Converts Observable to a Signal automatically
  // result() will now be a reactive Signal
  result = toSignal(this.countriesService.getCountries(), { initialValue: [] });
}