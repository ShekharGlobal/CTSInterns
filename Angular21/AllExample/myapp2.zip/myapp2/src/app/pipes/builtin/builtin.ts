import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-builtin',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './builtin.html',
  styleUrl: './builtin.css'
})
export class Builtin {
  // 1 & 2: Case Pipes
  var_one: string = "hello Every One";
  var_two: string = "ANGULAR FRAMEWORK";
  
  // 3: TitleCase
  var_three: string = "learning angular is fun";

  // 4: Currency
  var_four: number = 1500.50;

  // 5: JSON
  var_five: any = {
    p_id: 101,
    p_name: "Laptop",
    p_details: { ram: "16GB", ssd: "512GB" }
  };

  // 6: Slice (Works on Strings and Arrays)
  var_six_str: string = "FullStackDeveloper";
  var_six_arr: number[] = [10, 20, 30, 40, 50, 60, 70];

  // 7: Number (Decimal)
  var_seven: number = 123.456789;

  // 8: Percent
  var_eight: number = 0.85;

  // 9: Date
  var_nine: Date = new Date();

  // 10: Async (Promise example)
  var_ten: Promise<string> = new Promise((resolve) => {
    setTimeout(() => resolve("Data Loaded Successfully!"), 3000);
  });
}