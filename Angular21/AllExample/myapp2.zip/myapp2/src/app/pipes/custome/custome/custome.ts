import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReversePipe } from '../reverse-pipe';
import { MessagePipe } from '../message-pipe';

@Component({
  selector: 'app-custome',
  imports: [CommonModule, ReversePipe, MessagePipe],
  templateUrl: './custome.html',
  styleUrl: './custome.css',
})
export class Custome {
msg: string = "Welcome to Angular 21";
user: string = "Cognizant";
greeting: string = "Good Morning";


}
