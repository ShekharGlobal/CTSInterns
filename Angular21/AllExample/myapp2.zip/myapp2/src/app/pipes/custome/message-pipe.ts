import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'message2',
})
//: transform(value: string, name: string): string means “take the input string (value), 
// combine it with the provided parameter (name), and return a new string.”

export class MessagePipe implements PipeTransform {
  transform(value: string, name: string, greet: string): string {
    return `Hello ${value}, ${name},${greet}`;
  }
}
