import { Component, signal } from '@angular/core';
import { ChildComponent } from '../child/child';

@Component({
  selector: 'app-parent',
  standalone: true,
  imports: [ChildComponent],
  templateUrl: './parent.html',
  styleUrl: './parent.css'
})
export class ParentComponent {
  // 1. The main data source (Signal)
  employees = signal([
    { name: 'Mohan', salary: 50000 },    
    { name: 'Ramesh', salary: 45000 },    
    { name: 'Vijay', salary: 40000 }
  ]);

  // 2. Handler for the event coming from the Child
  // Update the signal by filtering out the selected employee
  //currentList: This is the current array of employees stored inside the signal.
  //.filter(): This creates a new array. It iterates through every employee in the list and checks a condition.
  //emp !== empToRemove: This is the condition. It says: "Keep every employee except the one that matches empToRemove."

  handleRemove(empToRemove: any) {
        this.employees.update(currentList => 
      currentList.filter(emp => emp !== empToRemove)
    );
  }

  //  A method to reset the list
  resetList() {
    this.employees.set([
      { name: 'Mohan', salary: 50000 },    
      { name: 'Ramesh', salary: 35000 },    
      { name: 'Vijay', salary: 40000 }
    ]);
  }
}