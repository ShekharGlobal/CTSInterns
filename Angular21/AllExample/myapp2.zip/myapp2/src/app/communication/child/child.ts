import { Component, input, output, computed } from '@angular/core';

@Component({
  selector: 'app-child',
  standalone: true,
  templateUrl: './child.html',
  styleUrl: './child.css'
})
export class ChildComponent {
  // 1. Receive the list from Parent as a Signal
  employeeList = input.required<any[]>();

  // 2. Define an Output function to send data back up
  onRemoveRequest = output<any>();

  // 3. Derived state: Automatically recalculates when employeeList changes
  totalSalary = computed(() => {
    return this.employeeList().reduce((sum, emp) => sum + emp.salary, 0);
  });
//Since the child doesn't "own" the data, it must ask the parent to make the change.
  removeItem(emp: any) {
    // 4. Emit the event so the Parent can handle the actual deletion
    this.onRemoveRequest.emit(emp);
  }
}