import { Component, signal } from '@angular/core';
import {RouterLink, RouterOutlet,RouterLinkActive } from '@angular/router';

//RouterLink-Binds a URL path to an element (usually <a> or <button>), 
// enabling navigation without reloading the page.

//RouterOutlet-Acts as a placeholder in the template where the routed component will be displayed.

//RouterLinkActive-Adds CSS classes to elements when their linked route is currently active.

@Component({
  selector: 'app-root',
  imports: [RouterLink,RouterOutlet,RouterLinkActive],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App {
  protected readonly title = signal('myapp2');
}
