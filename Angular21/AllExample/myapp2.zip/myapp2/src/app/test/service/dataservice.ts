import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root' // This makes the service available globally
})
export class DataService {

  constructor() { }

  /**
   * Multiplies two numbers and returns the result.
   * @param a First number
   * @param b Second number
   */
  multiply(a: number, b: number): number {
    return a * b;
  }
}