import { TestBed } from '@angular/core/testing';
import { DataService } from './dataservice'; 

//karma with jasmine starts the execution from describe()
describe('DataService', () => {
  let service: DataService;

  beforeEach(() => {
    // Standard Angular way to initialize a service for testing
    TestBed.configureTestingModule({
      providers: [DataService]
    });

    service = TestBed.inject(DataService);
  });

  //it will execute before each describe() function
//Ensures the service was actually created and isn't null or undefined.

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

//Checks if the output matches the exact value expected.
  it('should multiply two numbers correctly (3 * 5 = 15)', () => {
    const result = service.multiply(3, 5);
    expect(result).toBe(15);
  });

//Tests an "edge case" (multiplying by zero) to ensure the logic handles different inputs correctly.
  it('should return 0 if one of the numbers is 0', () => {
    const result = service.multiply(10, 0);
    expect(result).toBe(0);
  });

});