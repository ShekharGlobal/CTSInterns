import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Calculator } from './calculator';
import { DataService } from '../../service/dataservice';
//This test suite is an Integration Test. While the previous service test only checked the math, this test checks if the TypeScript logic and the HTML template are talking to each other correctly.

describe('Calculator', () => {
  let component: Calculator;
  let fixture: ComponentFixture<Calculator>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Calculator], 
      providers: [DataService]
    }).compileComponents();

    fixture = TestBed.createComponent(Calculator);
    component = fixture.componentInstance;
    // We do NOT call detectChanges here to avoid the initial "check" conflict
  });

  it('should display "Result: 0" on load', () => {
    fixture.detectChanges(); // First and only check for this test
    const compiled = fixture.nativeElement as HTMLElement;
    const display = compiled.querySelector('#display')?.textContent;
    expect(display).toContain('Result: 0');
  });

  it('should update display to "Result: 20" after clicking multiply', async () => {
    // 1. Trigger the logic
    component.doMultiply(10, 2);
    
    // 2. Wait for the asynchronous microtasks to clear,returns a Promise that only resolves once the Task Queue is empty
    await fixture.whenStable();
    
    // 3. Now trigger the change detection
    fixture.detectChanges();
    
    const compiled = fixture.nativeElement as HTMLElement;
    const display = compiled.querySelector('#display')?.textContent;
    expect(display).toContain('Result: 20');
  });
});