import { Component } from '@angular/core';
import { DataService } from '../../service/dataservice';

@Component({
  selector: 'app-calculator',
  standalone: true,
  template: `
    <div class="calc-wrapper">
      <h2 id="display">Result: {{ total }}</h2>
      <button (click)="doMultiply(10, 2)">Multiply 10 x 2</button>
    </div>
  `
})
export class Calculator{
  total = 0;

  constructor(private dataService: DataService) {}

  doMultiply(a: number, b: number) {
    this.total = this.dataService.multiply(a, b);
  }
}