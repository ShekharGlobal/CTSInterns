import { Component, signal } from '@angular/core';
import { LifecycleChild } from '../lifecycle-child/lifecycle-child';

@Component({
  selector: 'app-lifecycle-parent',
  imports: [LifecycleChild],
  template: `
    <div class="container mt-5">
      <h1>Angular 21 Signals Lab</h1>
      
      <button (click)="increment()" class="btn btn-success me-2">
        Change Signal (Trigger Effect)
      </button>
      
      <hr>
      <app-lifecycle-child [count]="score()"></app-lifecycle-child>
    </div>
  `
})
export class LifecycleParent {

// Parent state managed as a Signal
  score = signal(0);

  increment() {
    this.score.update(v => v + 1);
  }

  
}
