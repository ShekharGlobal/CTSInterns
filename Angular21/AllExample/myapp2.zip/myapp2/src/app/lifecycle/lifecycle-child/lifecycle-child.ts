import { 
  Component, 
  input, 
  effect, 
  OnInit, 
  afterNextRender, 
  DestroyRef, 
  inject,
  signal 
} from '@angular/core';

@Component({
  selector: 'app-lifecycle-child',
  standalone: true,
  imports: [],
  template: `
    <div class="card p-3 shadow-sm mt-3">
      <h2 class="text-success">Signal Lifecycle Hooks</h2>
      <div class="alert alert-success">
        <h4>Current Count: {{ count() }}</h4>
      </div>

      <div class="mt-3">
        <h5>Lifecycle Log:</h5>
        <div class="border rounded bg-light p-2" style="max-height: 200px; overflow-y: auto;">
          @for (log of lifecycleLogs(); track $index) {
            <div class="text-primary font-monospace small">
              > {{ log }}
            </div>
          }
        </div>
      </div>

      <p class="mt-2">Check console for reactive signal logs!</p>
    </div>
  `
})
export class LifecycleChild implements OnInit {

  // 1. Replacement for @Input() - This is a Signal Input
  count = input.required<number>();

  // Signal to store log messages for the browser UI
  lifecycleLogs = signal<string[]>([]);

  // Injecting DestroyRef is the modern way to handle Cleanup
  private destroyRef = inject(DestroyRef);

  constructor() {
    this.addLog('Constructor initialized');

    // 2. Replacement for ngOnChanges
    // Effects run whenever the signals inside them change
    effect(() => {
      console.log(`Effect: The count signal changed to: ${this.count()}`);
      this.addLog(`Effect: Count updated to ${this.count()}`);
    });

    // 3. New API: Replacement for ngAfterViewInit
    afterNextRender(() => {
      console.log('afterNextRender: DOM is ready (runs once).');
      this.addLog('afterNextRender: DOM is ready');
    });
  }

  ngOnInit(): void {
    console.log('ngOnInit: Initializing component logic.');
    this.addLog('ngOnInit: Initializing component');

    // 5. Modern Cleanup (Replacement for ngOnDestroy)
    this.destroyRef.onDestroy(() => {
      // This will still print to console as the component UI will be gone
      console.log('DestroyRef: Cleaning up resources before death.');
    });
  }

  // Helper method to update the browser UI logs
  private addLog(methodName: string) {
    this.lifecycleLogs.update(logs => [...logs, methodName]);
  }
}