import { Component } from '@angular/core';

@Component({
  selector: 'app-one-way',
  templateUrl: './one-way.html',
  styleUrls: ['./one-way.css']
})
export class OneWay {

  title = "One Way Data Binding Example";
  username = "Angular Student";
  
}
