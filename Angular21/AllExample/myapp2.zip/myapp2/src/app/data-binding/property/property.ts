import { Component } from '@angular/core';

@Component({
  selector: 'app-property',
  imports: [],
  templateUrl: './property.html',
  styleUrl: './property.css',
})
export class Property {

imageUrl: string = 'images/img1.jpg';

changeImage() {
  this.imageUrl = 'images/img2.jpg';
}



}
