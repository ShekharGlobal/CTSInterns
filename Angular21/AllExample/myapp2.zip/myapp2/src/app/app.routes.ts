import { Routes } from '@angular/router';

export const routes: Routes = [

{
path:'one-way',
loadComponent:() =>
    import('./data-binding/one-way/one-way')
    .then(m => m.OneWay)

},
{
    path: 'image',
    loadComponent: () =>
      import('./data-binding/property/property')
        .then(m => m.Property),
  },

{
    path: 'two-way',
    loadComponent: () =>
      import('./data-binding/two-way/two-way')
        .then(m => m.TwoWay),
  },
  {
  path: 'service',
  loadComponent: () =>
    import('./servicexample/component/countries/countries')
      .then(m => m.CountriesComponent),
},
{
  path: 'comm',
  loadComponent: () => import('./communication/parent/parent')
              .then(m => m.ParentComponent)
},
{
path: 'tdf',
  loadComponent: () => import('./form/tdf/tdf')
              .then(m => m.Tdf)
},
{
path: 'reactive',
  loadComponent: () => import('./form/reactive/reactive')
              .then(m => m.Reactive)
},

{
path: 'builtin',
  loadComponent: () => import('./pipes/builtin/builtin')
              .then(m => m.Builtin)
},

{
path: 'custome',
  loadComponent: () => import('./pipes/custome/custome/custome')
              .then(m => m.Custome)
},

{
  path: 'lifecycle',
  loadComponent: () => import('./lifecycle/lifecycle-parent/lifecycle-parent')
                       .then(m => m.LifecycleParent)
}

];
