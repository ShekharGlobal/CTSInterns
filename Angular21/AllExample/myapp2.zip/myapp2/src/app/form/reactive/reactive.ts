import { Component, inject } from '@angular/core';
import { NonNullableFormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [ReactiveFormsModule, JsonPipe],
  templateUrl: './reactive.html',
  
})
export class Reactive {
  // Injecting the FormBuilder (NonNullable ensures values don't become 'null' on reset)
  private fb = inject(NonNullableFormBuilder);

  // Define the form structure
  profileData = this.fb.group({
    uname: ['Naresh', [
      Validators.required, 
      Validators.minLength(3), 
      Validators.maxLength(6)
    ]],
    addr: this.fb.group({
      address: ['']
    }),
    gender: [''],
    country: ['']
  });

  register(): void {
    if (this.profileData.valid) {
      // Accessing the strongly typed value
      console.log('Form Submitted:', this.profileData.getRawValue());
    } else {
      this.profileData.markAllAsTouched();
    }
  }
}