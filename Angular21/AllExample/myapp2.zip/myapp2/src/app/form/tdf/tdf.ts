import { Component } from '@angular/core';
import { FormsModule, NgForm } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tdf',
  standalone: true, // Explicitly marked as standalone
  imports: [FormsModule, CommonModule],
  templateUrl: './tdf.html', 
  styles: [`
    .form-container { 
      max-width: 400px; 
      margin: 2rem auto; 
      padding: 20px;
      border: 1px solid #eee;
      border-radius: 8px;
      font-family: sans-serif; 
    }
    
    .form-group { margin-bottom: 1.5rem; }
    
    label { 
      font-weight: bold; 
      display: block; 
      margin-bottom: 0.5rem; 
    }
    
    input, select { 
      width: 100%; 
      padding: 10px; 
      border: 1px solid #ccc; 
      border-radius: 4px; 
      box-sizing: border-box; /* Ensures padding doesn't break width */
    }

    /* 1. Visited but empty/wrong (Red) */
    input.ng-invalid.ng-touched { border: 2px solid red; }

    /* 2. Modified and correct (Green) */
    input.ng-valid.ng-dirty { border: 2px solid green; }

    /* 3. Modified but still wrong (Orange) - great for email typing */
    input.ng-invalid.ng-dirty { border: 2px solid orange; }

    button { 
      width: 100%;
      padding: 10px; 
      background-color: #007bff; 
      color: white; 
      border: none; 
      border-radius: 4px; 
      cursor: pointer;
      font-size: 1rem;
    }

    button:disabled { 
      background-color: #ccc; 
      cursor: not-allowed; 
    }
  `]
})
export class Tdf {
  // Initial state for the form data
  userProfile = {
    userName: '',
    role: 'developer', 
    department: '',    
    agreedToTerms: false 
  };

  onSave(form: NgForm) {
    if (form.valid) {
      console.log('Form is valid! Data:', form.value);
      // You can also access this.userProfile directly since it's two-way bound
      console.log('Model Data:', this.userProfile);
    } else {
      console.error('Form is invalid. Check red fields.');
    }
  }
}