import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    baseUrl: 'http://localhost:4200',
    // This tells Cypress to look for E2E files in your custom test folder
    specPattern: 'src/app/test/e2e/**/*.cy.ts',
  },

  component: {
    devServer: {
      framework: 'angular',
      bundler: 'webpack',
    },
    // This is for Cypress Component Testing (different from E2E)
    specPattern: 'src/app/test/component/**/*.cy.ts',
  },
});