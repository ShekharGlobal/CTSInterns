import { Injectable, inject } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { Country } from "../models/country";

@Injectable({
  providedIn: "root"
})
export class CountriesService {
  private http = inject(HttpClient);
  private readonly API_URL = "https://restcountries.com/v3.1/all?fields=name,capital,region,population,flags";

  public getCountries(): Observable<Country[]> {
    return this.http.get<Country[]>(this.API_URL);
  }
}