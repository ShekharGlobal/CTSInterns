package com.cts.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration; // ✅ FIXED
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

/**
 * Defines how requests are secured. Registers your JWT filter in the Spring
 * Security chain. Configures authentication and password encoding.
 * ================================================================================
 * 
 * @Configuration + @EnableMethodSecurity
 * @Configuration: Marks this as a Spring configuration class.
 * @EnableMethodSecurity: Enables method-level security annotations
 *                        like @PreAuthorize and @Secured.
 *  ===============================================================================
 *                        
 * User logs in via /auth/login.
 * Credentials checked using AuthenticationManager.
 * If valid, a JWT is generated (JwtUtil).
 * User calls a protected endpoint.
 * JwtFilter intercepts request, validates JWT.
 * If valid, sets authentication in SecurityContextHolder.
 * Spring Security sees the user as authenticated and applies role-based access.
 */
@Configuration
@EnableMethodSecurity
public class SecurityConfig {

	// Injecting JwtFilter
	// custom filter that validates JWTs on each request.
	@Autowired
	private JwtFilter jwtFilter;

	// Security Filter Chain
	/**
	 * Disables CSRF: Common in stateless APIs using JWTs. Authorization
	 * rules:/auth/** and /students/** → open to everyone. All other endpoints →
	 * require authentication.
	 */
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	    http
	        // 1. Enable CORS and Disable CSRF
	        .cors(cors -> cors.configure(http)) 
	        .csrf(csrf -> csrf.disable())
	        
	        .authorizeHttpRequests(auth -> auth
	            // 2. Allow OPTIONS requests (Preflight) for all endpoints
	            .requestMatchers(org.springframework.http.HttpMethod.OPTIONS, "/**").permitAll()
	            
	            // 3. Public endpoints
	            .requestMatchers("/auth/**", "/students/**").permitAll()
	            
	            // 4. Everything else (including /schools/**) needs authentication
	            .anyRequest().authenticated()
	        )
	        
	        // 5. Add your JWT filter
	        .addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);

	    return http.build();
	}

    //Adds JwtFilter:
	// Provides an AuthenticationManager bean.
	// Used in login endpoints to authenticate credentials.
	@Bean
	public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
		return config.getAuthenticationManager();
	}

	//Password Encoder
	//Defines password hashing strategy.
    //BCryptPasswordEncoder is secure and recommended for storing passwords.
	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
}