package com.cts.controller;

public class JwtResponse {

    private String token;

    public JwtResponse() {} // Default constructor for Jackson

    public JwtResponse(String token) {
        this.token = token;
    }

    // MANDATORY: Spring needs this getter to include "token" in the JSON response
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}