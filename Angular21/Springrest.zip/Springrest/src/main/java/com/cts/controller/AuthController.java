package com.cts.controller;

import com.cts.dto.*;
import com.cts.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {
        try {
            authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
            );

            // Generate the token
            String token = jwtUtil.generateToken(request.getEmail());

            // PRINT TO CONSOLE HERE
            System.out.println("--------------------------------------");
            System.out.println("JWT Generated for: " + request.getEmail());
            System.out.println("Token: " + token);
            System.out.println("--------------------------------------");

            return ResponseEntity.ok(new JwtResponse(token));

        } catch (BadCredentialsException e) {
            System.err.println("Authentication failed for: " + request.getEmail());
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }
}