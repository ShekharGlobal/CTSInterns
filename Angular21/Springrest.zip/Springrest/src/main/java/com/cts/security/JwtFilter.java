package com.cts.security;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Client sends request with header:Authorization: Bearer <jwt-token>
 * JwtFilter extracts token and username.
 * Validates token using JwtUtil.
 * Loads user details from DB.
 * Sets authentication in SecurityContextHolder.
 * Request proceeds with authenticated user context.
 * JwtFilter extends OncePerRequestFilter, meaning it runs once per request.
 */
//Registers this filter as a Spring bean so it can be injected into the security chain.
@Component
public class JwtFilter extends OncePerRequestFilter {

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomUserDetailsService userDetailsService;

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws ServletException, IOException {

		//Step 1: Extract Authorization Heade
		final String authHeader = request.getHeader("Authorization");

		String username = null;
		String token = null;

		//Step 2: Parse Token
		if (authHeader != null && authHeader.startsWith("Bearer ")) {
			token = authHeader.substring(7);
			username = jwtUtil.extractUsername(token);
		}
		
		//Step 3: Check Authentication Context

		if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {

			//Step 4: Load User Details
			UserDetails userDetails = userDetailsService.loadUserByUsername(username);

			//Step 5: Validate Token
			if (jwtUtil.validateToken(token, userDetails.getUsername())) {

				//Step 6: Set Authentication
				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
						null, userDetails.getAuthorities());

				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
		}

		//Step 7: Continue Filter Chain
		chain.doFilter(request, response);
	}
}