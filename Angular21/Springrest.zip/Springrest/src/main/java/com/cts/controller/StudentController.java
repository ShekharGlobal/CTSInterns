package com.cts.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import com.cts.bean.Student;
import com.cts.repository.StudentRepository;

@RestController
@RequestMapping("/students")
@CrossOrigin(origins = "http://localhost:4200")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    public Student register(@RequestBody Student student) {
        // CRITICAL: Encode password so AuthenticationManager can read it later
        student.setPassword(passwordEncoder.encode(student.getPassword()));
        
        if(student.getRole() == null) {
            student.setRole("STUDENT");
        }

        return studentRepository.save(student);
    }

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }
}