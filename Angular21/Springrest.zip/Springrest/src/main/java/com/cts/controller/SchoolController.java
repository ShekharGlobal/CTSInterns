package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bean.School;
import com.cts.repository.SchoolRepository;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/schools")
public class SchoolController {

    @Autowired
    private SchoolRepository schoolRepository;

    // ADMIN ONLY
    @PostMapping("/add")
    @PreAuthorize("hasAnyRole('ADMIN','STUDENT')")
    public School addSchool(@RequestBody School school) {
        return schoolRepository.save(school);
    }

    // BOTH ADMIN + STUDENT
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','STUDENT')")
    public List<School> getAllSchools() {
        return schoolRepository.findAll();
    }
}