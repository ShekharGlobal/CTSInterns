package com.cts.security;

import java.util.List;
/**
 * User logs in with email + password.
 * Spring Security calls loadUserByUsername(email).
 * Repository fetches the Student record.
 * If found, Spring Security gets a UserDetails object with credentials + roles.
 * Spring Security then checks the password and grants access based on roles.
 */

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cts.bean.Student;
import com.cts.repository.StudentRepository;

@Service
public class CustomUserDetailsService implements UserDetailsService {

	//Dependency Injection
    @Autowired
    private StudentRepository studentRepository;

    //loadUserByUsername Method
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

    	//Fetching the User
        Student user = studentRepository.findByEmail(username)
                .orElseThrow(() -> new UsernameNotFoundException("Student not found"));

        //Returning a Spring Security User
        //Wraps  Student entity into Spring Security’s built-in User object.
        return new org.springframework.security.core.userdetails.User(
                user.getEmail(),
                user.getPassword(),
                List.of(new SimpleGrantedAuthority("ROLE_" + user.getRole()))
        );
    }
}