package com.cts.dto;

import java.util.List;

import org.springframework.hateoas.RepresentationModel;

public class SchoolDTO extends RepresentationModel<SchoolDTO>{

    private Long schoolId;
    private String schoolName;
    private String city;

    private List<StudentDTO> studentList;

	public Long getSchoolId() {
		return schoolId;
	}

	public void setSchoolId(Long schoolId) {
		this.schoolId = schoolId;
	}

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public List<StudentDTO> getStudentList() {
		return studentList;
	}

	public void setStudentList(List<StudentDTO> studentList) {
		this.studentList = studentList;
	}

    
}