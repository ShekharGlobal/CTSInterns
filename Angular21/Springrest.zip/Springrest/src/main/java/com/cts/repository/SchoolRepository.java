package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cts.bean.School;

public interface SchoolRepository extends JpaRepository<School,Long> { 

    @Query("SELECT s FROM School s WHERE s.city = :city AND SIZE(s.studentList) = (SELECT MAX(SIZE(sc.studentList)) FROM School sc WHERE sc.city = :city)")
    List<School> findSchoolWithMaxStudentsInCity(@Param("city") String city);

}