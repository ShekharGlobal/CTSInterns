package com.cts.service;

import java.util.List;

import com.cts.dto.SchoolDTO;
import com.cts.dto.StudentDTO;

public interface SchoolService {

    void addSchool(SchoolDTO schoolDTO);

    void registerStudentToSchool(Long schoolId, List<StudentDTO> students);

    List<SchoolDTO> schoolWithMaximumStudents(String city);
}