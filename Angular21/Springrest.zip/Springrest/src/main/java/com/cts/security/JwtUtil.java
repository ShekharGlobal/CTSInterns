package com.cts.security;

import io.jsonwebtoken.*;

/**
 * Generate JWTs when a user successfully logs in.
 * Extract information (like username) from a token.
 * Validate tokens to ensure they’re authentic and not expired.
 * =================================================================
 * User logs in → generateToken(username) creates a JWT.
 * Client stores JWT and sends it in Authorization: Bearer <token> header.
 * JwtFilter intercepts request → extracts token.
 * JwtUtil.extractUsername(token) gets the username.
 * JwtUtil.validateToken(token, username) ensures token is valid.
 * If valid, Spring Security authenticates the user.

 */
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {
//Secret Key
//Used to sign and verify JWTs.
// min 32 chars
	
	private final String SECRET_KEY = "mysecretkeymysecretkeymysecretkey"; 

	//Generate Token
	/**
	 * Creates a JWT with:
	 * Subject → the username
	 * IssuedAt → current time
	 * Expiration → 1 hour from now
	 * Signature → signed using HS256 and your secret key
	 * Returns the token string.
	 */
	public String generateToken(String username) {
		return Jwts.builder().setSubject(username).setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60)) // 1 hour
				.signWith(Keys.hmacShaKeyFor(SECRET_KEY.getBytes()), SignatureAlgorithm.HS256).compact();
	}

	//Extract Username
	//Reads the subject field (username) from the token.
	public String extractUsername(String token) {
		return getClaims(token).getSubject();
	}

	//Validate Token
	//The token’s subject matches the expected username & not expired
	public boolean validateToken(String token, String username) {
		return username.equals(extractUsername(token)) && !isTokenExpired(token);
	}

	//Get Claims
	//Parses the token using the secret key.
	//Returns the payload (Claims) which contains subject, expiration, etc.
	private Claims getClaims(String token) {
		return Jwts.parserBuilder().setSigningKey(SECRET_KEY.getBytes()).build().parseClaimsJws(token).getBody();
	}

	//Check Expiration
	//Compares the expiration date with the current time.
	private boolean isTokenExpired(String token) {
		return getClaims(token).getExpiration().before(new Date());
	}
}