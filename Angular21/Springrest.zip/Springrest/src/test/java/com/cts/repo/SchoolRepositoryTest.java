package com.cts.repo;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.cts.bean.School;
import com.cts.repository.SchoolRepository;

@DataJpaTest
class SchoolRepositoryTest {

	@Autowired
	private SchoolRepository schoolRepo;

	@Test
	void testSaveSchool() {

		School school = new School();
		school.setSchoolName("ABC School");
		school.setCity("Delhi");

		schoolRepo.save(school);

		List<School> schools = schoolRepo.findAll();

		assertEquals(1, schools.size());
	}
}