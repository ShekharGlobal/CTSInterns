package com.cts.service;

import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.modelmapper.ModelMapper;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import com.cts.bean.School;
import com.cts.dto.SchoolDTO;
import com.cts.repository.SchoolRepository;

@ExtendWith(MockitoExtension.class)
class SchoolServiceTest {

    @Mock
    private SchoolRepository schoolRepo;

    @Mock
    private ModelMapper modelMapper;   

    @InjectMocks
    private SchoolServiceImpl schoolService;

    @Test
    void testAddSchool() {

        SchoolDTO dto = new SchoolDTO();
        dto.setSchoolName("ABC School");

        School school = new School();

        // mock modelmapper behavior
        Mockito.when(modelMapper.map(dto, School.class)).thenReturn(school);

        schoolService.addSchool(dto);

        verify(schoolRepo, Mockito.times(1)).save(Mockito.any());
    }
}