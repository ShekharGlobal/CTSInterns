// src/app/services/auth.service.ts
import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs';

//separate services (e.g., AuthService, SchoolService, StudentService)
//  because of the Single Responsibility Principle (SRP).

//Auth service strictly for security and tokens

@Injectable({ providedIn: 'root' })
export class Auth{
  private http = inject(HttpClient);
  private readonly API_URL = 'http://localhost:8090/auth';
  
  // State management using Signals
  //Initial Value: It looks into the browser's localStorage immediately when the app loads.
  // If a token exists, the signal starts with that string.If not, it starts as null.

  token = signal<string | null>(localStorage.getItem('token'));

  //The Logic: It uses the double-bang operator (!!)  to convert the token value into a boolean:If token is
  //  a string (exists) --> true.If token is null -->false.
//The adminGuard() checks if isAuthenticated() is true
  isAuthenticated = computed(() => !!this.token());

  //Payload: The credentials object (containing the email and password from the form)
  //  is sent in the request body as JSON.

  login(credentials: any) {

    return this.http.post<{token: string}>(`${this.API_URL}/login`, credentials).pipe(
   
      //The .pipe(tap(...)) Operator The pipe is an RxJS tool that allows  to perform "side effects" before the data reaches to component.
  //tap: This operator is used to "peek" at the data. It allows you to do something with the response (like saving it) without changing the data itself.
      
  tap(res => {
        //This saves the JWT string into the browser's Local Storage.

        localStorage.setItem('token', res.token);

        //This updates the Signal.

        this.token.set(res.token);
      })
    );
  }

  logout() {
    localStorage.removeItem('token');
    this.token.set(null);
  }
}