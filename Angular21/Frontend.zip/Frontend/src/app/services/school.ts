import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

//School service strictly for school data.
@Injectable({ providedIn: 'root' })
export class School {
  private http = inject(HttpClient);
  // Change this to the base URL
  private readonly API_URL = 'http://localhost:8090/schools';

  // Hits: GET http://localhost:8090/schools
  getSchools(): Observable<any[]> {
    return this.http.get<any[]>(this.API_URL);
  }

  // Hits: POST http://localhost:8090/schools/add
  addSchool(schoolData: any): Observable<any> {
    return this.http.post(`${this.API_URL}/add`, schoolData);
  }
}