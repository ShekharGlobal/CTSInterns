import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
//Student service if you plan to add specific student management logic later.
@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private http = inject(HttpClient);
  private readonly API_URL = 'http://localhost:8090/students';

  // 1. Register (Public - no token needed)
  register(studentData: any): Observable<any> {
    return this.http.post(`${this.API_URL}/register`, studentData);
  }

  // 2. Get All Students (ADMIN Only)
  getAllStudents(): Observable<any[]> {
    return this.http.get<any[]>(this.API_URL);
  }

  // 3. Get Student Profile (STUDENT Only)
  getProfile(): Observable<string> {
    return this.http.get(`${this.API_URL}/profile`, { responseType: 'text' });
  }
}