// src/app/components/login/login.component.ts
import { Component, inject } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Auth } from '../../services/auth';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule],
  template: `
    <div class="login-container">
      <form [formGroup]="loginForm" (ngSubmit)="onSubmit()">
        <input formControlName="email" placeholder="Email" type="email">
        <input formControlName="password" placeholder="Password" type="password">
        <button type="submit" [disabled]="loginForm.invalid">Login</button>
      </form>
    </div>
  `
})
export class Login{
  private fb = inject(NonNullableFormBuilder);
  private auth = inject(Auth);
  private router = inject(Router);

  loginForm = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]]
  });

  onSubmit() {
    this.auth.login(this.loginForm.value).subscribe
    (
         {   
           next: () => this.router.navigate(['/schools']),
           error: (err) => alert('Login Failed')
         }
    );

  }
}