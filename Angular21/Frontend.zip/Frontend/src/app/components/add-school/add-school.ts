import { Component, inject } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { School } from '../../services/school';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-school',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './add-school.html',
  styleUrl: './add-school.css'
})
export class AddSchool {
  private fb = inject(NonNullableFormBuilder);
  // 2. Renamed variable to schoolService to avoid shadowing issues
  private schoolService = inject(School); 
  private router = inject(Router);

  schoolForm = this.fb.group({
    schoolName: ['', Validators.required],
    schoolType: ['', Validators.required],
    city: ['', Validators.required]
  });

  onSubmit() {
    if (this.schoolForm.valid) {
      // 3. Call the method on the correctly named service instance
      this.schoolService.addSchool(this.schoolForm.getRawValue()).subscribe({
        next: () => {
          alert('School added successfully!');
          this.router.navigate(['/schools']);
        },
        error: (err: any) => {
          if (err.status === 403) {
            alert('Access Denied: Only Admins can add schools.');
          } else {
            alert('Error adding school: ' + err.message);
          }
        }
      });
    }
  }
}