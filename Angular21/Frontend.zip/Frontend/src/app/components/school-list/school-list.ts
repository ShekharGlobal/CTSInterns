import { Component, inject, signal, OnInit } from '@angular/core';
import { School } from '../../services/school';
import { Router, RouterLink } from '@angular/router'; // Added RouterLink
import { Auth } from '../../services/auth';

@Component({
  selector: 'app-school-list',
  standalone: true,
  imports: [RouterLink], // Necessary for routerLink to work in HTML
  template: `
    <div class="header">
      <h2>Available Schools</h2>
      <div class="button-group">
        <button class="add-btn" routerLink="/add-school">+ Add School</button>
        <button class="logout-btn" (click)="onLogout()">Logout</button>
      </div>
    </div>

    <div class="container">
      <ul>
        @for (item of schools(); track item.schoolId) {
          <li>
            <strong>{{ item.schoolName }}</strong> - {{ item.city }}
            <span class="badge">{{ item.schoolType }}</span>
          </li>
        } @empty {
          <p>No schools found or access denied.</p>
        }
      </ul>
    </div>
  `,
  styles: [`
    .header { 
      display: flex; 
      justify-content: space-between; 
      align-items: center; 
      padding: 1rem;
      background: #f8f9fa;
      border-bottom: 2px solid #e9ecef;
    }
    .button-group { display: flex; gap: 10px; }
    .add-btn { background: #28a745; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; }
    .logout-btn { background: #dc3545; color: white; border: none; padding: 8px 16px; border-radius: 4px; cursor: pointer; }
    ul { list-style: none; padding: 0; margin-top: 20px; }
    li { 
      padding: 15px; 
      border-bottom: 1px solid #eee; 
      display: flex; 
      justify-content: space-between; 
      align-items: center;
    }
    .badge { background: #e7f1ff; color: #0d6efd; padding: 2px 8px; border-radius: 12px; font-size: 0.8rem; }
  `]
})
export class SchoolList implements OnInit {
  private schoolService = inject(School);
  private authService = inject(Auth);
  private router = inject(Router);

  schools = signal<any[]>([]);

  ngOnInit() {
    this.loadSchools();
  }

  loadSchools() {
    this.schoolService.getSchools().subscribe({
      next: (data) => {
        this.schools.set(data);
      },
      error: (err) => {
        console.error('Fetch error:', err);
        if (err.status === 403) {
          alert('You do not have permission to view this list.');
        }
      }
    });
  }

  onLogout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}