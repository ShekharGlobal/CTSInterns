// src/app/components/register/register.component.ts
import { Component, inject } from '@angular/core';
import { NonNullableFormBuilder, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { StudentService } from '../../services/studentservice'; // Import your service

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [ReactiveFormsModule],
  templateUrl: './register.html',
  styleUrl: './register.css'
})
export class Register {
  private fb = inject(NonNullableFormBuilder);
  private studentService = inject(StudentService); // Inject service instead of HttpClient
  private router = inject(Router);

  registerForm = this.fb.group({
    studentRollNumber: ['', Validators.required],
    studentName: ['', Validators.required],
    studentAge: [0, [Validators.required, Validators.min(5)]],
    studentGender: ['Male'],
    studentGrade: ['', Validators.required],
    studentSection: ['', Validators.required],
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    role: ['STUDENT']
  });

  onSubmit() {
    if (this.registerForm.valid) {
      // Use the service method instead of calling http directly
      this.studentService.register(this.registerForm.getRawValue()).subscribe({
        next: () => {
          alert('Registration Successful!');
          this.router.navigate(['/login']);
        },
        error: (err) => alert('Registration Failed!')
      });
    }
  }
}