import { Routes, Router } from '@angular/router';
import { inject } from '@angular/core';
import { Auth } from './services/auth';
import { Login } from './components/login/login';
import { SchoolList } from './components/school-list/school-list';
import { AddSchool } from './components/add-school/add-school';
import { Register } from './components/register/register';

/**
 * Functional Guard
 * Checks if the user is authenticated via the AuthService signal.
 */
const authGuard = () => {
  const isAuth = inject(Auth).isAuthenticated();

  //Using parseUrl is the "clean" way for guards to handle redirects.
  return isAuth ? true : inject(Router).parseUrl('/login');
};

export const routes: Routes = [
  // Public Routes
  { path: 'login', component: Login },
  { path: 'register', component: Register },

  // Protected Routes (Require JWT via authGuard)
  { 
    path: 'add-school', 
    component: AddSchool, 
    canActivate: [authGuard] 
  },
  { 
    path: 'schools', 
    component: SchoolList, 
    canActivate: [authGuard] 
  },

  // Default and Redirects
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/login' } // Catch-all for undefined paths
];