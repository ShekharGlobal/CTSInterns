package com.cts.mapper;
/**
 * Purpose of StudentMapper
   This class transforms between
   StudentDTO (used in API layer)
   Student (Entity used in database)
   Think of it like a translator — helping the front-end and back-end talk clearly.
 * 
 */
import com.cts.dto.*;
import com.cts.entity.*;
import com.cts.repository.CourseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class StudentMapper {

    @Autowired
    private CourseRepository courseRepository;

    //Converts StudentDTO (from client/API) into a Student object 
    //(used to save into the database).
    public Student toEntity(StudentDTO dto) {
        if (dto == null) return null;

        //Creates a Student object using data from DTO.
        Student student = Student.builder()
                .id(dto.getId())
                .name(dto.getName())
                .address(toAddressEntity(dto.getAddress()))
                .build();

 /**
  * It takes the list of course enrollments sent from the front-end (inside StudentDTO) and:
    Finds the matching Course in the database.
    Creates a new Enrollment entity.
    Links each Enrollment to the Student object being created.
    Sets the enrollment date to today.
    Finally, attaches all these enrollments to the Student
         */
        if (dto.getEnrollments() != null) {
            List<Enrollment> enrollments = dto.getEnrollments().stream()
                .map(enrollmentDTO -> {
                    Course course = courseRepository.findById(enrollmentDTO.getCourseId())
                        .orElseThrow(() -> new RuntimeException("Course not found: " + enrollmentDTO.getCourseId()));
                    return Enrollment.builder()
                            .course(course)
                            .student(student)
                            .enrollmentDate(LocalDate.now())
                            .build();
                }).collect(Collectors.toList());

            student.setEnrollments(enrollments);
        }

        return student;
    }
//Uses toAddressEntity() to convert the nested address.
    private Address toAddressEntity(AddressDTO dto) {
        if (dto == null) return null;
        return Address.builder()
                .city(dto.getCity())
                .state(dto.getState())
                .zip(dto.getZip())
                .build();
    }

    public StudentDTO toDto(Student student) {
        
        return StudentDTO.builder()
                .id(student.getId())
                .name(student.getName())
                .build();
    }
}
