package com.cts.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.cts.dto.StudentDTO;
import com.cts.entity.Student;
import com.cts.mapper.StudentMapper;
import com.cts.service.StudentService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/students")
public class StudentController {
	
    @Autowired private StudentService studentService;
    @Autowired private StudentMapper studentMapper;

    @GetMapping
    public List<StudentDTO> getAll() {
        return studentService.getAllStudents().stream()
                .map(studentMapper::toDto)
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public StudentDTO getById(@PathVariable Long id) {
        return studentMapper.toDto(studentService.getStudent(id));
    }

    @PostMapping("/save")
    public StudentDTO create(@Valid @RequestBody StudentDTO studentDTO) {
        Student student = studentMapper.toEntity(studentDTO);
        return studentMapper.toDto(studentService.saveStudent(student));
    }

    @PutMapping("/{id}")
    public StudentDTO update(@PathVariable Long id, @Valid @RequestBody StudentDTO studentDTO) {
        studentDTO.setId(id);
        Student student = studentMapper.toEntity(studentDTO);
        return studentMapper.toDto(studentService.saveStudent(student));
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        studentService.deleteStudent(id);
    }
}
