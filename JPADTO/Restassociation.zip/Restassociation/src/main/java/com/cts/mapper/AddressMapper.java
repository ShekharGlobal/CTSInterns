package com.cts.mapper;

import org.springframework.stereotype.Component;

import com.cts.dto.AddressDTO;
import com.cts.entity.Address;

@Component
public class AddressMapper {
    public AddressDTO toDto(Address address) {
        if (address == null) return null;
        return AddressDTO.builder()
                .id(address.getId())
                .city(address.getCity())
                .state(address.getState())
                .zip(address.getZip())
                .build();
    }

    public Address toEntity(AddressDTO dto) {
        if (dto == null) return null;
        return Address.builder()
                .id(dto.getId())
                .city(dto.getCity())
                .state(dto.getState())
                .zip(dto.getZip())  
                .build();
    }
}
