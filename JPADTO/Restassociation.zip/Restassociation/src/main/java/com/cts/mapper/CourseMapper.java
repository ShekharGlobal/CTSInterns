package com.cts.mapper;

import org.springframework.stereotype.Component;

import com.cts.dto.CourseDTO;
import com.cts.entity.Course;

@Component
public class CourseMapper {

    public CourseDTO toDto(Course course) {
        if (course == null) return null;
        return CourseDTO.builder()
                .id(course.getId())
                .name(course.getTitle())  
                .description(course.getDescription())
                .build();
    }

    public Course toEntity(CourseDTO dto) {
        if (dto == null) return null;
        return Course.builder()
                .id(dto.getId())
                .title(dto.getName())  // Fixed: should be 'title' not 'name'
                .description(dto.getDescription())
                .build();
    }
}