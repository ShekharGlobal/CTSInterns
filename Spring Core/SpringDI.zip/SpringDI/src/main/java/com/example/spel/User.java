package com.example.spel;

import org.springframework.stereotype.Component;

@Component
public class User {

    private String membershipType = "NORMAL";
    private double cartAmount = 5000;

    public String getMembershipType() {
        return membershipType;
    }

    public double getCartAmount() {
        return cartAmount;
    }
}
