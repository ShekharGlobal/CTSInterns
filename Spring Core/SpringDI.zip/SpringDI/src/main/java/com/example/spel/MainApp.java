package com.example.spel;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {

	public static void main(String[] args) {

		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

		DiscountService discountService = context.getBean(DiscountService.class);

		System.out.println("Calculated Discount: " + discountService.getDiscount());
	}
}
