package com.example.spel;

import org.springframework.stereotype.Component;
import java.util.List;

@Component
public class Customer {

	private String name = "Ravi";
	private int age = 30;
	private double salary = 60000;
	private int creditScore = 750;
	private boolean premiumCustomer = true;
	private List<String> existingLoans = List.of("HOME");
	
	

	public String getName() {
		return name;
	}

	public int getAge() {
		return age;
	}

	public double getSalary() {
		return salary;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public boolean isPremiumCustomer() {
		return premiumCustomer;
	}

	public List<String> getExistingLoans() {
		return existingLoans;
	}
}
