package com.example.spel;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
/**
 * SpEL is powerful for dynamic configuration, conditional logic,
 *  and cross-bean access without cluttering Java code.
 * Avoids hardcoded values
 * Easy to modify business rules
 *  Clean separation of logic and configuration
 *  
 *  SpEL is a Spring expression language used to dynamically 
 *  evaluate expressions, access bean properties, invoke methods, 
 *  and apply business logic at runtime.
 */
@Component
public class DiscountService {

 @Value("#{user.membershipType == 'PREMIUM' ? user.cartAmount * 0.20 : user.cartAmount * 0.05}")
    private double discount;

    public double getDiscount() {
        return discount;
    }
}
