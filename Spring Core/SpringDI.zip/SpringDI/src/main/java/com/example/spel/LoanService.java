package com.example.spel;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class LoanService {
//The @Value annotation should be used only when injecting external 
//properties or evaluating SpEL expressions. 
//If the value is static, normal field initialization is preferred.
//""" ... """ (Text Block)
	
    @Value("""
        #{
          customer.age >= 21 &&
          customer.salary >= 40000 &&
          customer.creditScore >= 700 &&
          customer.existingLoans.size() < 3 &&
          (customer.premiumCustomer ? true : customer.salary > 50000)
        }
        """)
    private boolean eligible;

    @Value("#{customer.salary * (customer.premiumCustomer ? 10 : 6)}")
    private double eligibleLoanAmount;

    @Value("#{customer.name?.toUpperCase()}")
    private String customerName;

    public boolean isEligible() {
        return eligible;
    }

    public double getEligibleLoanAmount() {
        return eligibleLoanAmount;
    }

    public String getCustomerName() {
        return customerName;
    }
}
