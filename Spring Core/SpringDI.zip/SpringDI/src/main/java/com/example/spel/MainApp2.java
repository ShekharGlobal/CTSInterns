package com.example.spel;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp2 {

    public static void main(String[] args) {

        ApplicationContext context =
                new AnnotationConfigApplicationContext(AppConfig2.class);

        LoanService loanService = context.getBean(LoanService.class);

        System.out.println("Customer Name: " + loanService.getCustomerName());
        System.out.println("Loan Eligible: " + loanService.isEligible());
        System.out.println("Eligible Loan Amount: " + loanService.getEligibleLoanAmount());
    }
}
