package com.cts.resource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class EngineConfig {

    @Bean(name = "dieselEngine")  // Explicit bean name
    public Engine dieselEngine() {
        return new DieselEngine();
    }

    @Bean(name = "petrolEngine")
    @Primary  // This will be the default if @Resource(name="") is not used
    public Engine petrolEngine() {
        return new PetrolEngine();
    }
}
