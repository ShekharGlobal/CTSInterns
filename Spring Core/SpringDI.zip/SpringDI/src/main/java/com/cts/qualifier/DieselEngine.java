package com.cts.qualifier;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

// Step 2: Implement Different Engines
@Component("dieselEngine")
@Primary 
class DieselEngine implements Engine {
    //@Override
    public void start() {
        System.out.println("Diesel Engine started");
    }
}