package com.cts.inject;
public interface Engine {
    void start();
}
