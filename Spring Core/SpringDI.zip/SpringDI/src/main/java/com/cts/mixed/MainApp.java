package com.cts.mixed;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import java.util.Map;

public class MainApp {
    public static void main(String[] args) {
        // Load both XML and Java configurations
        ApplicationContext xmlContext = new ClassPathXmlApplicationContext("spring-config.xml");
        //ApplicationContext javaContext = new AnnotationConfigApplicationContext(AppConfig.class);

        // Get the Library bean from XML
        Library library = (Library) xmlContext.getBean("library");

        // Inject the authors map from Java config
        //library.setAuthors(javaContext.getBean("authorMap", Map.class));

        // Display books with authors
        library.displayBooks();
    }
}
