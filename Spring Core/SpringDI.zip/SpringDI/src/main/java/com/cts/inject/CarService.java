package com.cts.inject;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.springframework.stereotype.Service;

@Service
public class CarService {

    @Inject
    @Named("dieselEngine")  // Injecting by name
    private Engine engine;

    public void startCar() {
        engine.start();
    }
}
