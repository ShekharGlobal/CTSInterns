package com.cts.resource;
import jakarta.annotation.Resource;
import org.springframework.stereotype.Service;

@Service
public class CarService {

    @Resource(name = "dieselEngine")  // Injecting by bean name
    private Engine engine;

    public void startCar() {
        engine.start();
    }
}
