package com.cts.qualifier;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;
//If no @Qualifier is provided, Spring injects the bean marked with @Primary.
@Component("petrolEngine")
//@Primary // This will be the default bean if no qualifier is specified
class PetrolEngine implements Engine {
    //@Override
    public void start() {
        System.out.println("Petrol Engine started");
    }
}