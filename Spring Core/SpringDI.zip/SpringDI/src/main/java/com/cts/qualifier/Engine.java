package com.cts.qualifier;

// Step 1: Define Engine Interface
interface Engine {
	void start();
}