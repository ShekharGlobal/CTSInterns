package com.cts.qualifier;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

@SpringBootApplication
public class AutowiringConflictDemo {
    public static void main(String[] args) {
        ApplicationContext context = SpringApplication.run(AutowiringConflictDemo.class, args);
        CarService carService = context.getBean(CarService.class);
        carService.startCar(); // Expected Output: Diesel Engine started
    }
}
