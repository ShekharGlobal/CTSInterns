package com.cts.resource;
public interface Engine {
    void start();
}
