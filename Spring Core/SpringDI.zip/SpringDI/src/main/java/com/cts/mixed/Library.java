package com.cts.mixed;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

//@Component
public class Library {
    private List<String> books;
    private Map<String, String> authors;

    // Setters for dependency injection
    public void setBooks(List<String> books) {
        this.books = books;
    }

    public void setAuthors(Map<String, String> authors) {
        this.authors = authors;
    }

    public void displayBooks() {
        System.out.println("Library Books:");
        for (String book : books) {
            String author = authors.get(book);
            System.out.println("- " + book + " by " + (author != null ? author : "Unknown"));
        }
    }
}
