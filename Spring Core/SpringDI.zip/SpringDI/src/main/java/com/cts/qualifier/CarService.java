package com.cts.qualifier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

// Step 3: Car Service Using Different Ways to Resolve Autowiring
@Service
class CarService {
    private final Engine engine;// Type: Engine

    // Using @Qualifier to specify the bean
    @Autowired // Autowires by type (Engine)
    public CarService(@Qualifier("petrolEngine") Engine engine) {
        this.engine = engine;
    }

    public void startCar() {
        engine.start();
    }
}