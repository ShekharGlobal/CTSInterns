package com.cts.mixed;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfig {
    @Bean
    public Map<String, String> authorMap() {
        Map<String, String> authors = new HashMap<String, String>();
        authors.put("The Alchemist", "Paulo Coelho");
        authors.put("Clean Code", "Robert C. Martin");
        authors.put("Spring in Action", "Craig Walls");
        return authors;
    }
}
