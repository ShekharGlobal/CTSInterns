package com.cts.inject;
import jakarta.inject.Named;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EngineConfig {

    @Bean
    @Named("dieselEngine")  // Named bean for JSR-330
    public Engine dieselEngine() {
        return new DieselEngine();
    }

    @Bean
    @Named("petrolEngine")
    public Engine petrolEngine() {
        return new PetrolEngine();
    }
}
