package com.coforge.collection;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Demo {
    public static void main(String[] args) {
  ApplicationContext ctx = 
		  new ClassPathXmlApplicationContext("list2.xml");

        Library library = (Library) ctx.getBean("library");

        library.displayBooks();
    }
}
