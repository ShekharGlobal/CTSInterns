package com.coforge.setter;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
/**Role of IOC Container
 *  Reads applicationContext.xml
    Creates objects (Employee, Address)
    Injects dependencies (setter injection)
    Gives ready-to-use objects to the application
 */
public class Test {
//IOC
	public static void main(String[] args) {
  ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
		
		Employee e = (Employee) context.getBean("obj");
		e.display();

	}

}
