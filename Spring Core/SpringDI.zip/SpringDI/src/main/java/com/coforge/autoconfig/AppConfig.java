package com.coforge.autoconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
@ComponentScan("com.coforge.autoconfig")
public class AppConfig {
/**
*   Spring provides two ways to create beans:
*  1. Class-level (@Component) for application classes
*  2. Method-level (@Bean) for external or custom-created classes
*/
	
	@Primary
	@Bean(name = "officeAddress")
	public Address officeAddress() {
		Address address = new Address();
		address.setAddressLine1("CP");
		address.setCity("New Delhi");
		address.setState("Delhi");
		address.setCountry("India");
		return address;
	}

	@Bean(name = "homeAddress")
	public Address homeAddress() {
		Address address = new Address();
		address.setAddressLine1("DLF Phase 3");
		address.setCity("Gurgaon");
		address.setState("Haryana");
		address.setCountry("India");
		return address;
	}

	@Bean
	public Employee employee() {
		Employee employee = new Employee();
		employee.setId(1);
		employee.setName("Vijay");
		return employee;
	}
}
