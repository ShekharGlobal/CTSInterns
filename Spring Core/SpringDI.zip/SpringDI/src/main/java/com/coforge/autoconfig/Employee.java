package com.coforge.autoconfig;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Employee {

	private int id;
	private String name;
//Spring resolves the dependency first by TYPE and then by NAME.
	
	/**
	 *   If no Address bean exists → error

         If one Address bean exists → @Qualifier is not even needed

        If multiple Address beans exist → go to Step 2
	 */
	@Autowired
	@Qualifier("homeAddress")  // Injecting by bean by name
	private Address address;  // by type
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public void display() {
		System.out.println(id + " " + name);
		System.out.println(address);
	}

}
