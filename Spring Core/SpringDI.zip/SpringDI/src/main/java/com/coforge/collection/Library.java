package com.coforge.collection;
import java.util.List;

public class Library {

    private List<Book> books;

    // Setter for DI
    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public void displayBooks() {
        books.forEach(b -> System.out.println(b.getTitle()));
    }
}
