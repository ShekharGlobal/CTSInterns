package com.coforge.autoconfig;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class AppMain {

	public static void main(String[] args) {
//IoC Container = CONCEPT	
//ApplicationContext = IMPLEMENTATION
//Spring container is the ApplicationContext, 
// which implements the IoC principle.
/**
 * Implements IoC
 * Creates beans
 * Injects dependencies
 * Manages lifecycle
 */
ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

		Employee e1=  ctx.getBean("employee", Employee.class);
		
		e1.display();
	}

}
