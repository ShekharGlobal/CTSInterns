package com.coforge.springhb;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class UserHibernateDao {
    private final SessionFactory sessionFactory;

    @Autowired // ✅ Ensures Spring injects sessionFactory properly
    public UserHibernateDao(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Transactional
    public void saveUser(UserHB user) {
        sessionFactory.getCurrentSession().save(user);

        // Simulate an error for rollback demonstration
        if (user.getUsername().equals("error")) {
            throw new RuntimeException("Simulated Error: Rollback transaction");
        }
    }
}