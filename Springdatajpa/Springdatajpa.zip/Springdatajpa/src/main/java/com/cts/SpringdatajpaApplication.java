package com.cts;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.cts.bean.Employee;
import com.cts.dao.EmployeeDAO;

@SpringBootApplication
public class SpringdatajpaApplication implements CommandLineRunner {

    @Autowired
    private EmployeeDAO employeeDAO;   // ✅ Autowiring DAO

    public static void main(String[] args) {
        SpringApplication.run(SpringdatajpaApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        Employee e1 = new Employee();
        e1.setEmpId("E1");
        e1.setEmpName("Vijay");
        e1.setDepartment("IT");
        e1.setSalary(50000);

        Employee e2 = new Employee();
        e2.setEmpId("E2");
        e2.setEmpName("David");
        e2.setDepartment("HR");
        e2.setSalary(40000);

        // Insert using DAO
        employeeDAO.addEmployee(e1);
        employeeDAO.addEmployee(e2);

        // Fetch and print
        List<Employee> list = employeeDAO.getAllEmployees();

        for (Employee emp : list) {
            System.out.println(emp.getEmpName() + " - " + emp.getDepartment());
        }
    }
}