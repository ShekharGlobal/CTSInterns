package com.cts.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.bean.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, String> {

    List<Employee> findByDepartment(String department);
}