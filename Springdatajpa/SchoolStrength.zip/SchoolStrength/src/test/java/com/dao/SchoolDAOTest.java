package com.dao;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.bean.School;
import com.bean.Student;
import com.dao.SchoolDAO;
import com.repository.SchoolRepository;
import com.repository.StudentRepository;

@ExtendWith(MockitoExtension.class)
class SchoolDAOTest {

    @Mock
    private SchoolRepository schoolRepo;

    @Mock
    private StudentRepository studentRepo;

    @InjectMocks
    private SchoolDAO schoolDAO;

    private School school;

    @BeforeEach
    void setUp() {
        school = new School();
        school.setSchoolId("S1");
        school.setSchoolName("ABC School");
        school.setCity("Chennai");
    }

    // ✅ Test addSchool
    @Test
    void testAddSchool() {
        when(schoolRepo.save(any(School.class))).thenReturn(school);

        schoolDAO.addSchool(school);

        verify(schoolRepo, times(1)).save(school);
    }

    // ✅ Test registerStudentToSchool
    @Test
    void testRegisterStudentToSchool() {

        Student s1 = new Student();
        s1.setStudentRollNumber("R1");

        List<Student> students = Arrays.asList(s1);

        when(schoolRepo.findById("S1")).thenReturn(Optional.of(school));

        schoolDAO.registerStudentToSchool("S1", students);

        // verify student is linked
        assertEquals(school, s1.getSchool());

        verify(studentRepo, times(1)).saveAll(students);
    }

    // ✅ Test schoolWithMaximumStudents
    @Test
    void testSchoolWithMaximumStudents() {

        List<School> schoolList = Arrays.asList(school);

        when(schoolRepo.findSchoolWithMaxStudentsInCity("Chennai"))
                .thenReturn(schoolList);

        List<School> result = schoolDAO.schoolWithMaximumStudents("Chennai");

        assertEquals(1, result.size());
        assertEquals("ABC School", result.get(0).getSchoolName());

        verify(schoolRepo, times(1))
                .findSchoolWithMaxStudentsInCity("Chennai");
    }
}