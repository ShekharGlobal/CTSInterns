package com.dao;
 
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.bean.School;
import com.bean.Student;
import com.repository.SchoolRepository;
import com.repository.StudentRepository;
 
 
@Repository
@Component  
public class SchoolDAO {

 
    @Autowired
    private SchoolRepository schoolRepo;
    
    @Autowired
    private StudentRepository studentRepo;

 
    @Transactional
	public void addSchool(School school){
		schoolRepo.save(school);
	}

 
	public void registerStudentToSchool(String schoolId, List<Student> students ) {
		Optional<School> schoolOpt = schoolRepo.findById(schoolId);
		if (schoolOpt.isPresent()){
		    School school = schoolOpt.get();
		    for(Student student: students){
		        student.setSchool(school);
		    }
		    studentRepo.saveAll(students);
		}
	}
 
	
	public List<School> schoolWithMaximumStudents(String city){
	    return schoolRepo.findSchoolWithMaxStudentsInCity(city);
		}
 
	
}