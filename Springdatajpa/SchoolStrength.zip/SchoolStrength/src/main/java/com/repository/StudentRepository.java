package com.repository;
 
 
import org.springframework.data.jpa.repository.JpaRepository;

//import com.bean;

import com.bean.Student;
 
 
public interface StudentRepository extends JpaRepository<Student,String> {
 
}

 