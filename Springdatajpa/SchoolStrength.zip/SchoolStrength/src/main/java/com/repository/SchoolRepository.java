package com.repository;
 
 
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

// import com.bean;
import com.bean.School;
 
public interface SchoolRepository extends JpaRepository<School,String> { 
    @Query("SELECT s from School s where s.city =: city AND SIZE (s.studentList) = (SELECT MAX(SIZE(sc.studentList)) FROM School sc where sc.city=:city)")
    List <School> findSchoolWithMaxStudentsInCity(@Param("city") String city);
 
}