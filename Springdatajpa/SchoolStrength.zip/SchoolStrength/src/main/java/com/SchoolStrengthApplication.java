package com;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.bean.School;
import com.bean.Student;
import com.dao.SchoolDAO;

@SpringBootApplication
public class SchoolStrengthApplication implements CommandLineRunner {

    @Autowired
    private SchoolDAO schoolDAO;   
    
    public static void main(String[] args) {
        SpringApplication.run(SchoolStrengthApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        School school = new School();
        school.setSchoolId("S1");
        school.setSchoolName("ABC Public School");
        school.setSchoolType("Private");
        school.setCity("Chennai");

        schoolDAO.addSchool(school);

        List<Student> students = new ArrayList<>();

        Student s1 = new Student();
        s1.setStudentRollNumber("R1");
        s1.setStudentName("Arun");
        s1.setStudentAge(15);
        s1.setStudentGender("Male");
        s1.setStudentGrade("10");
        s1.setStudentSection("A");

        students.add(s1);

        schoolDAO.registerStudentToSchool("S1", students);

        List<School> result =
                schoolDAO.schoolWithMaximumStudents("Chennai");

        for (School sc : result) {
            System.out.println(sc.getSchoolName());
        }
    }
}