package com.cta.goodlsp;

interface FlyingBird {
	void fly();
}
