package com.cta.goodlsp;

// Penguin does not implement FlyingBird since it cannot fly
class Penguin implements Bird {
	void makeSound() {
		System.out.println("Penguin makes a honking sound!");
	}
}