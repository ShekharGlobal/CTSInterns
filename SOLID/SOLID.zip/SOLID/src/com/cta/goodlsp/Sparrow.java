package com.cta.goodlsp;

class Sparrow implements Bird, FlyingBird {
    public void fly() {
        System.out.println("Sparrow is flying!");
    }
    
    void makeSound() {
        System.out.println("Sparrow chirps!");
    }
}