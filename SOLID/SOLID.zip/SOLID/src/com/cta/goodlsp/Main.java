package com.cta.goodlsp;
public class Main {
    public static void main(String[] args) {
        // Sparrow can fly
        FlyingBird sparrow = new Sparrow();
        sparrow.fly();
        
        // General bird reference (Penguin)
        Bird penguin = new Penguin();
        if (penguin instanceof Penguin) {
            ((Penguin) penguin).makeSound();
        }
    }
}






