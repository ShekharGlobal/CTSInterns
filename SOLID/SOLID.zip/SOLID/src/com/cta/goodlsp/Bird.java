package com.cta.goodlsp;

interface Bird {
}
