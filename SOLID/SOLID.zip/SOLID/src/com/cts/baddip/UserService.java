package com.cts.baddip;

class UserService {
	
	MySQLDatabase database = new MySQLDatabase(); // Tightly coupled

	void fetchUser() {
		database.connect();
	}
}
