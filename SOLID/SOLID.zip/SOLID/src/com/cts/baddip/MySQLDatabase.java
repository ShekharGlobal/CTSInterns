package com.cts.baddip;
class MySQLDatabase {
    void connect() { /* Connects to MySQL */ }
}
