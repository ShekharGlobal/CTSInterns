package com.cts.badisp;

interface Worker {
	void work();

	void eat();
}
