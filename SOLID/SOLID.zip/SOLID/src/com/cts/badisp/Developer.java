package com.cts.badisp;

class Developer implements Worker {
	public void work() {
		/* Writes code */ }

	public void eat() {
		/* Irrelevant for a remote worker */ }
}
