package com.cts.goodisp;

interface Workable {
	void work();
}
