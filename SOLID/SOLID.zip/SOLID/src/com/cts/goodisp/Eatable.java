package com.cts.goodisp;

interface Eatable {
	void eat();
}
