package com.cts.goodisp;

class OfficeWorker implements Workable, Eatable {
	public void work() {
		/* Works in office */ }

	public void eat() {
		/* Takes lunch break */ }
}
