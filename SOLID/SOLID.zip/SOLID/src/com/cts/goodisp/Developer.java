package com.cts.goodisp;

class Developer implements Workable {
	public void work() {
		/* Writes code */ }
}
