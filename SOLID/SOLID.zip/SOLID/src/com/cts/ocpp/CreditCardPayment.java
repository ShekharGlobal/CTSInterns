package com.cts.ocpp;

class CreditCardPayment implements Payment {
	public void processPayment() {
		/* Process Credit Card Payment */ }
}
