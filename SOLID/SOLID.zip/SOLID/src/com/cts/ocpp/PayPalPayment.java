package com.cts.ocpp;

class PayPalPayment implements Payment {
	public void processPayment() {
		/* Process PayPal Payment */ }
}
