package com.cts.ocpp;

interface Payment {
	void processPayment();
}
