package com.cts.ocpp;

public class PaymentProcessor {
	void processPayment(Payment payment) {
		payment.processPayment();
	}

	public static void main(String[] args) {
		PaymentProcessor processor = new PaymentProcessor();

		Payment creditCardPayment = new CreditCardPayment();
		Payment paypalPayment = new PayPalPayment();

		System.out.println("Processing Credit Card Payment:");
		processor.processPayment(creditCardPayment);

		System.out.println("Processing PayPal Payment:");
		processor.processPayment(paypalPayment);
	}
}
