package com.cts.badlsp;
class Bird {
    void fly() { 
    	
    /* All birds fly */
    	System.out.println("All Birds fly");
    	
    }
}
