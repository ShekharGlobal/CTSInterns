package com.cts.badlsp;

public class Main {
	public static void main(String[] args) {
		Bird sparrow = new Bird();
		sparrow.fly(); // Works fine

		Bird penguin = new Penguin();
		try {
			penguin.fly(); // Throws Exception
		} catch (UnsupportedOperationException e) {
			System.out.println(e.getMessage());
		}
	}
}
