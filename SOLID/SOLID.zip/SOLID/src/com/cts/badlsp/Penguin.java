package com.cts.badlsp;

class Penguin extends Bird {
	void fly() {
		throw new UnsupportedOperationException("Penguins cannot fly!");
	}
}
