package com.cts.gooddip;

class UserService {
	
	private Database database;

	UserService(Database database) {
		this.database = database;
	}

	void fetchUser() {
		database.connect();
	}
}
