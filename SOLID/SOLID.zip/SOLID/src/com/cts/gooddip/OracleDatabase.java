// OracleDatabase.java
package com.cts.gooddip;

class OracleDatabase implements Database {
	public void connect() {
		System.out.println("Connected with Oracle");
	}
}
