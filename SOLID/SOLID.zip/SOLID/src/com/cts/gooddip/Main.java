// Main.java
package com.cts.gooddip;

public class Main {
	public static void main(String[] args) {
		// Using MySQL
		Database mySQL = new MySQLDatabase();
		UserService userService1 = new UserService(mySQL);
		userService1.fetchUser();

		// Using Oracle
		Database oracle = new OracleDatabase();
		UserService userService2 = new UserService(oracle);
		userService2.fetchUser();
	}
}
