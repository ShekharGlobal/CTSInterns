package com.cts.gooddip;

class MySQLDatabase implements Database {
	public void connect() {
		/* Connects to MySQL */ 
		System.out.println("connected with MySQL");
	
	}
}
