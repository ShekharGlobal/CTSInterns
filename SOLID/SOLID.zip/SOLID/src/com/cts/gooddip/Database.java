package com.cts.gooddip;

interface Database {
	void connect();
}
