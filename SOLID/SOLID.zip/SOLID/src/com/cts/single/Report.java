package com.cts.single;
//bad design



class Report {
	void generateReport() {
		/* Generates report */ }

	void printReport() {
		/* Prints report */ }

	void saveReport() { /* Saves report to database */
	}
}
