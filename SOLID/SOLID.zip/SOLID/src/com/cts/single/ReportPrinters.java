package com.cts.single;
class ReportPrinters {
	void printReport() {
		/* Prints report */ }
}