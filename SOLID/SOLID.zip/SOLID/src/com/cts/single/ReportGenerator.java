package com.cts.single;
//Good Design
class ReportGenerator {
	void generateReport() {
		/* Generates report */ }
}




