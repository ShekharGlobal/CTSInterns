package com.cts.single;
class ReportSavers {
	void saveReport() {
		/* Saves report to database */ }
}