package com.org.controller;



import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.entity.Course;
import com.org.repository.CourseRepository;

@RestController
@RequestMapping("/courses")
public class CourseController {

	@Autowired
	private CourseRepository repository;

	
	@PostMapping
	public Course saveCourse(@RequestBody Course course) {
		return repository.save(course);
	}

	
	@GetMapping("/{id}")
	public Course getCourse(@PathVariable Long id) {
		return repository.findById(id).orElseThrow(() -> new RuntimeException("Course not found"));
	}


	@PostMapping("/multiple")
	public List<Course> getCoursesByIds(@RequestBody List<Long> ids) {
		return repository.findAllById(ids);
	}

	// Add Students to Course (Many-to-Many support)
	@PostMapping("/{id}/students")
	public Course addStudentsToCourse(@PathVariable Long id, @RequestBody Set<Long> studentIds) {

		Course course = repository.findById(id).orElseThrow(() -> new RuntimeException("Course not found"));

		// initialize if null
		if (course.getStudentIds() == null) {
			course.setStudentIds(new HashSet<>());
		}

		course.getStudentIds().addAll(studentIds);

		return repository.save(course);
	}
}