package com.security.auth_service.controller;

import com.security.auth_service.util.JwtUtil;

import com.security.auth_service.repository.UserRepository;
import com.security.auth_service.dto.*;
import com.security.auth_service.entity.User;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

	@Autowired
	private AuthenticationManager authManager;
	@Autowired
	private JwtUtil jwtUtil;
	@Autowired
	private PasswordEncoder passwordEncoder;
	@Autowired
	private UserRepository userRepository;

	// Login endpoint
	@PostMapping("/login")
	public String login(@RequestBody AuthRequest request) {
		Authentication authentication = authManager
				.authenticate(new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword()));
		UserDetails user = (UserDetails) authentication.getPrincipal();
		// include roles in the token
		return jwtUtil.generateToken(user);
	}

	// Registration endpoint
	@PostMapping("/register")
	public String register(@RequestBody RegisterRequest request) {
		if (userRepository.findByUsername(request.getUsername()).isPresent()) {
			return "User already exists!";
		}
		User newUser = new User();
		newUser.setUsername(request.getUsername());
		newUser.setPassword(passwordEncoder.encode(request.getPassword()));

		// Assign role based on request (default ROLE_USER)
		if (request.getRole() != null && request.getRole().equalsIgnoreCase("ADMIN")) {
			newUser.getRoles().add("ROLE_ADMIN");
		} else {
			newUser.getRoles().add("ROLE_USER");
		}

		userRepository.save(newUser);
		return "User registered successfully with role " + newUser.getRoles();
	}
}
