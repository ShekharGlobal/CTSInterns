package com.gateway.util;

import java.security.Key;
/**
 * This JwtUtil class is your JWT helper utility — it handles the cryptographic
 *logic for verifying and decoding tokens
 * The class’s purpose is to extract claims from JWT tokens.
 */

import org.springframework.stereotype.Component;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Component
public class JwtUtil {
	private final String secret = "kuchtumsochokuchhamsochefirkhushikamokaaayajayho888kuchtumsochokuchhamsochefirkhushikamokaaayajayho888";

	private Key getSigningKey() {
		return Keys.hmacShaKeyFor(secret.getBytes());
	}

	public Claims extractClaims(String token) {
		return Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody();
	}
}
