package com.org;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
/*
 * user-amita, Amita@123
 * admin-ankit, Ankit@123
 * 
 * 
 */
@SpringBootApplication
@EnableFeignClients(basePackages = {"com.org.config"})
public class StudentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(StudentServiceApplication.class, args);
		
	
	}

}
