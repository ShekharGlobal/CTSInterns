package com.org.config;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.org.dto.Course;



//@FeignClient(name="course-service", url="${course.service.url}")
@FeignClient(name="API-GATEWAY-1")
public interface CourseClient {
	@GetMapping("/courses/{id}")
	public Course getCourse( @PathVariable  Long id);
	
	@PostMapping("/courses/multiple")
	public List<Course> getCousesById(@RequestBody List<Long> ids);

}
/*@Service
public class CourseServiceClient {

    private final RestTemplate restTemplate;
    private final String baseUrl;

    @Autowired
    public CourseServiceClient(RestTemplateBuilder builder,
                               @Value("${course.service.url}") String courseServiceUrl) {
        this.restTemplate = builder.build();
        this.baseUrl = courseServiceUrl;
    }

    // GET /courses/{id}
    public Course getCourse(Long id) {
        String url = baseUrl + "/courses/" + id;
        return restTemplate.getForObject(url, Course.class);
    }

    // POST /courses/multiple
    public List<Course> getCoursesById(List<Long> ids) {
        String url = baseUrl + "/courses/multiple";
        ResponseEntity<List<Course>> response =
                restTemplate.exchange(
                        url,
                        HttpMethod.POST,
                        new HttpEntity<>(ids),
                        new ParameterizedTypeReference<List<Course>>() {}
                );
        return response.getBody();
    }
}  */
