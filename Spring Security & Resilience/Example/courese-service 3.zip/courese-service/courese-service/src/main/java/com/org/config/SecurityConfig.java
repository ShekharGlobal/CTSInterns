package com.org.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class SecurityConfig {
	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
	    http.csrf(csrf -> csrf.disable())
	        .authorizeHttpRequests(auth -> auth
	            .requestMatchers("/courses/create").hasAuthority("ROLE_ADMIN")   // or "ROLE_ADMIN" depending on your convention
	            .requestMatchers("/courses/**").hasAnyAuthority("ROLE_USER","ROLE_ADMIN")
	            .anyRequest().authenticated()
	        )
	        .addFilterBefore(new RolesHeaderFilter(), UsernamePasswordAuthenticationFilter.class);
	    return http.build();
	}


}
