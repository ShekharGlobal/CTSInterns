package com.gateway.util;

import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import io.jsonwebtoken.Claims;
import reactor.core.publisher.Mono;

@Component
public class JwtAuthenticationFilter implements GlobalFilter {

    private final JwtUtil jwtUtil;

    public JwtAuthenticationFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    /*
     *  ServerWebExchange represents Http request and response in a reactive way
     * 
     * GatewayFilterChain passes the current request to the next filter or component
     * 
     */
    @Override
    public Mono<Void> filter(ServerWebExchange exchange,
    		GatewayFilterChain chain) {
    	//auth
        String path = exchange.getRequest().getURI().getPath();

        // Skip JWT validation for auth endpoints
        if (path.startsWith("/auth")) {
            return chain.filter(exchange);
        }

        String authHeader = exchange.getRequest().
        		getHeaders().getFirst(HttpHeaders.AUTHORIZATION);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }

        String token = authHeader.substring(7);
        try {
            Claims claims = jwtUtil.extractClaims(token);

            // Debug log to confirm token is being read
            System.out.println("JWT Token: " + token);
            System.out.println("User: " + claims.getSubject());
            System.out.println("Roles: " + claims.get("roles"));

            // Mutate request with headers
            ServerHttpRequest mutatedRequest = exchange.
            		getRequest().mutate()
                    .header("X-User", claims.getSubject())
                    .header("X-Roles", claims.get("roles").toString())
                    .build();

            return chain.filter(exchange.mutate().request(mutatedRequest).build());

        } catch (Exception e) {
            exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
            return exchange.getResponse().setComplete();
        }
    }
}
