package com.example.webflux.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.WebFluxTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.example.webflux.model.Product;
import com.example.webflux.service.ProductService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@WebFluxTest(ProductController.class)
public class ProductControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @MockBean
    private ProductService productService;

    private Product sampleProduct;

    @BeforeEach
    void setup() {
        sampleProduct = new Product();
        sampleProduct.setId("1");
        sampleProduct.setName("Phone");
        sampleProduct.setPrice(799.99);
    }

    @Test
    void testGetAllProducts() {
        when(productService.getAllProducts()).thenReturn(Flux.just(sampleProduct));

        webTestClient.get().uri("/products")
                .exchange()
                .expectStatus().isOk()
                .expectBodyList(Product.class).hasSize(1);
    }

    @Test
    void testCreateProduct() {
        when(productService.saveProduct(any())).thenReturn(Mono.just(sampleProduct));

        webTestClient.post().uri("/products")
                .bodyValue(sampleProduct)
                .exchange()
                .expectStatus().isOk()
                .expectBody(Product.class);
    }
}
