package com.example.webflux.service;

import com.example.webflux.model.Product;
import com.example.webflux.repository.ProductRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

import static org.mockito.Mockito.*;

public class ProductServiceTest {

    private final ProductRepository productRepository = mock(ProductRepository.class);
    private final ProductService productService = new ProductService(productRepository);

    @Test
    void testGetProductById() {
        Product product = new Product();
        product.setId("123");
        product.setName("Laptop");
        product.setPrice(999.99);

        when(productRepository.findById("123")).thenReturn(Mono.just(product));

        Mono<Product> result = productService.getProductById("123");

        StepVerifier.create(result)
                .expectNextMatches(p -> p.getId().equals("123") && p.getName().equals("Laptop"))
                .verifyComplete();
    }
}
