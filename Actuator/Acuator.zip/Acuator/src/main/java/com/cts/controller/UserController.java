package com.cts.controller;

import com.cts.model.User;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    private final MeterRegistry meterRegistry;

    public UserController(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @GetMapping("/user")
    public User getUser() {
        meterRegistry.counter("custom.user.api.hits").increment();
        return new User(1, "Alice");
    }
}
