package com.cts.value;


import lombok.Value;

@Value
public class Person2 {

    String name;
    int age;

    // Manually create "with" methods
    public Person2 withName(String name) {
        return new Person2(name, this.age);
    }

    public Person2 withAge(int age) {
        return new Person2(this.name, age);
    }

    public static void main(String[] args) {
        // Creating an instance of Person2
        Person2 person = new Person2("Laxman", 20);

        // Logging information about the person
        System.out.println(person);  // Person2(name=Laxman, age=20)

        // Using manually implemented "with" methods
        Person2 person2 = person.withName("Anusha");
        System.out.println(person2);  // Person2(name=Anusha, age=20)

        Person2 person3 = person.withAge(25);
        System.out.println(person3);  // Person2(name=Laxman, age=25)
    }
}
