package com.cts.example;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.LocalDateTime;

// Lombok annotation to generate getters, setters, toString, etc.
@Data
@AllArgsConstructor
@NoArgsConstructor
class User {
    private String username;
    private String email;
}