package com.cts.value;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import lombok.With;
import lombok.extern.slf4j.Slf4j;

@Builder
@Getter
@ToString
@EqualsAndHashCode
@Slf4j
@Data
public class Person {

	@With
	private final String name;

	@With
	private final int age;

	// Example method for logging
	public void logInfo() {
		log.info("Person created: {}", this);
	}

	public static void main(String[] args) {
		// Using Builder
		Person person = Person.builder().name("Vijay").age(21).build();

		// Log information about the person
		person.logInfo();

		// Using @With to generate "with" methods
		Person person2 = person.withName("Gagansindhu");
		System.out.println(person2); // Person(name=Gagansindhu, age=21)

		Person person3 = person.withAge(25);
		System.out.println(person3); // Person(name=Vijay, age=25)
	}
}
