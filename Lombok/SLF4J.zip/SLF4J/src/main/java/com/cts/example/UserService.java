package com.cts.example;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

class UserService {
    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    public void registerUser(User user) {
        logger.info("Registering user: {}", user.getUsername());

        if (user.getEmail().isEmpty()) {
            logger.warn("User {} has no email provided!", user.getUsername());
        }

        logger.debug("User {} registered at {}", user.getUsername(), LocalDateTime.now());
        logger.info("User registration successful: {}", user);
    }
}