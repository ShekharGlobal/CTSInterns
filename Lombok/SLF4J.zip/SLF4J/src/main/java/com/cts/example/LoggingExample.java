package com.cts.example;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoggingExample {

    // Create a logger instance for this class
    private static final Logger logger = LoggerFactory.getLogger(LoggingExample.class);

    public static void main(String[] args) {
        String userName = "Laxman";
        int userId = 1234;
        double transactionAmount = 250.75;

        // TRACE level (fine-grained information)
        logger.trace("This is a TRACE log message. This is usually very detailed information for debugging.");

        // DEBUG level (debugging info)
        logger.debug("Debugging user login with ID: {}", userId);

        // INFO level (informational message)
        logger.info("User '{}' logged in successfully.", userName);

        // WARN level (potential issue)
        if (transactionAmount > 100) {
            logger.warn("Transaction amount of {} is unusually high.", transactionAmount);
        }

        // ERROR level (serious issue)
        try {
            performCriticalOperation();
        } catch (Exception e) {
            logger.error("An error occurred during critical operation: ", e);
        }
    }

    // A method that might throw an exception
    public static void performCriticalOperation() throws Exception {
        throw new Exception("Critical operation failed");
    }
}
