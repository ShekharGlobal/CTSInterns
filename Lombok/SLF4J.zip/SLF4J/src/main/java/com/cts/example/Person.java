package com.cts.example;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.util.Objects;

import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@NoArgsConstructor
@AllArgsConstructor // This is sufficient to generate a constructor with all fields
public class Person {

	// Final field that requires initialization
	private String name;

	private int age;

	public static void main(String[] args) {
		// Using @NoArgsConstructor: Creates an object with no arguments.
		Person person1 = new Person();
		person1.setName("Abhishek");
		person1.setAge(21);
		System.out.println(person1); // Uses @ToString

		// Using @AllArgsConstructor: Creates an object with all fields initialized.
		Person person2 = new Person("Ravi", 30);
		System.out.println(person2); // Uses @ToString

		// Checking equality with @EqualsAndHashCode
		System.out.println("Are person1 and person2 equal? " + person1.equals(person2));

		// Checking hash codes with @EqualsAndHashCode
		System.out.println("person1 hash code: " + person1.hashCode());
		System.out.println("person2 hash code: " + person2.hashCode());
	}

	
}
