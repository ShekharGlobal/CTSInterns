package com.cts.advance;
public class Main {
    public static void main(String[] args) {
        // Using the builder to create an instance
        Person person = Person.builder()
                              .name("Vikram")
                              .age(22)
                              .address("123 OMR RD")
                              .build();
        
        System.out.println(person);  
    }
}
