package com.cts.example;
public class Main {
    public static void main(String[] args) {
        UserService userService = new UserService();

        // Creating a new user using Lombok-generated constructor
        User user1 = new User("Venkat", "venky@gmail.com");
        userService.registerUser(user1);
        

        // Creating a user with no email
        User user2 = new User("Laxmipriya", "");
        userService.registerUser(user2);
    }
}