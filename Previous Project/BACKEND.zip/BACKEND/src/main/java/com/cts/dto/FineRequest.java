package com.cts.dto;
 
import java.time.LocalDate;
 
import com.cts.model.Member;
 
import lombok.AllArgsConstructor;

import lombok.Data;

import lombok.NoArgsConstructor;
 
@Data

@AllArgsConstructor

@NoArgsConstructor

public class FineRequest {

	private Member member;

	private double amount;

	private String status;

	private LocalDate transactionDate;

}

 