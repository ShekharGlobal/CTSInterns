package com.cts.repository;


import com.cts.model.AvailableCopies;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface AvailableCopiesRepository extends JpaRepository<AvailableCopies, String> {

	Optional<AvailableCopies> findByIsbn(String isbn);
	
}
