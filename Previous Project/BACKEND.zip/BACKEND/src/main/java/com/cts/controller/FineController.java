package com.cts.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import com.cts.model.Fine;
import com.cts.service.FineService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/fines")
public class FineController {

    @Autowired
    private FineService fineService;
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/overdue/{page}")
    public Page<Fine> getAllFines(@PathVariable int page) {
        return fineService.getAllFines(page);
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("all/{id}")
    public ResponseEntity<Fine> getFineById(@PathVariable int id) {
        Fine fine = fineService.getFineById(id);
        return ResponseEntity.ok(fine);
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("update/{id}")
    public ResponseEntity<Fine> updateFine(@PathVariable int id, @RequestBody Fine fineDetails) {
        Fine updatedFine = fineService.updateFine(id, fineDetails);
        return ResponseEntity.ok(updatedFine);
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteFine(@PathVariable int id) {
        fineService.deleteFine(id);
        return ResponseEntity.noContent().build();
    }
    
    @PreAuthorize("hasAuthority('MEMBER')")
    @GetMapping("/{name}/{page}")
    public ResponseEntity<Page<Fine>> getFineHistoryByMemberName(@PathVariable String name, @PathVariable int page) {
        return ResponseEntity.ok(fineService.getFineHistoryByMemberName(name, page));
    }

    @PreAuthorize("hasAuthority('MEMBER')")
    @PostMapping("/pay/{id}")
    public ResponseEntity<Fine> payFine(@PathVariable int id) {
        Fine paidFine = fineService.payFine(id);
        return ResponseEntity.ok(paidFine);
    }
}
