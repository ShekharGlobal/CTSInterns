package com.cts.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.cts.model.Book;
import com.cts.model.BorrowTransaction;
import com.cts.model.Member;

@Repository
public interface BorrowRepository extends JpaRepository<BorrowTransaction, Integer> {

   	List<BorrowTransaction> findByStatus(String borrow_status);
    List<BorrowTransaction> findByBook(Book book);
	List<BorrowTransaction> findByMember(Member member);
	List<BorrowTransaction> findByBorrowDate(LocalDate borrowDate); 
	List<BorrowTransaction> findByReturnDate(LocalDate returnDate); 
	long countByMemberAndStatus(Member member, String status);
	Optional<BorrowTransaction> findByMemberAndBookAndStatus(Member member, Book book, String status);
    List<BorrowTransaction> findByMemberNameAndStatus(String name, String status);
	List<BorrowTransaction> findByStatusAndReturnDateBefore(String string, LocalDate now);
	List<BorrowTransaction> findByReturnDateAndStatus(LocalDate returnDate, String status);
	List<BorrowTransaction> findByReturnDateBeforeAndStatus(LocalDate date, String status);
	List<BorrowTransaction> findByMemberNameAndBookTitleAndStatus(String name, String title, String status);
	Page<BorrowTransaction> findByMemberName(String name,Pageable pageable);
	Page<BorrowTransaction> findByBookTitle(String title, Pageable pageable);
	Page<BorrowTransaction> findByStatus(String status, Pageable pageable);
	Page<BorrowTransaction> findByBorrowDate(LocalDate borrowDate, Pageable pageable);
	Page<BorrowTransaction> findByReturnDate(LocalDate returnDate, Pageable pageable);
	Page<BorrowTransaction> findAll(Pageable pageable);

}