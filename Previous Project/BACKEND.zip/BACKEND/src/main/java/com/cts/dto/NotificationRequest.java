package com.cts.dto;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class NotificationRequest {
    private String email;
    private String subject;
    private String message;
}
