package com.cts.service;

import com.cts.model.Login;
import com.cts.repository.LoginRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class LoginService {
    @Autowired
    private LoginRepository loginRepository;

    public void saveLogin(Long userId, String email, String role) {
    	log.info("Saved the {} login using {} ",role,email);
        Login login = new Login(userId, email, role);
        loginRepository.save(login);
    }
    
    public Page<Login> getAll(int page){
    	log.info("Fetching all the login details");
    	Pageable pageable = PageRequest.of(page, 3,Sort.by(Sort.Direction.ASC,"role"));
    	return loginRepository.findAll(pageable);
    }
}
