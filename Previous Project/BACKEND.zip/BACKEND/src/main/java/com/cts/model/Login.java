package com.cts.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "login")
@Data
@RequiredArgsConstructor
public class Login {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private String email;
    private String role;
    private LocalDateTime loginTime;

    public Login(Long userId, String email, String role) {
        this.userId = userId;
        this.email = email;
        this.role = role;
        this.loginTime = LocalDateTime.now();
    }
}
