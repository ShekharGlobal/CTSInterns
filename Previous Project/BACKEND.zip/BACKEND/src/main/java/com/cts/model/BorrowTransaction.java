package com.cts.model;

import java.time.LocalDate;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Entity
@Table(name="borrow")
@Data
@RequiredArgsConstructor
public class BorrowTransaction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="borrow_id")
    private int borrowId;
    
    @ManyToOne
    @JoinColumn(name="book_id")
    private Book book;

    @ManyToOne
    @JoinColumn(name="member_id", referencedColumnName = "memberId")
    private Member member;

    @Column(name="borrow_date")
    private LocalDate borrowDate;
    
    @Column(name="return_date")
    private LocalDate returnDate;
    
    @Column(name="book_returnOn")
    private LocalDate bookReturnOn;
    
    private String status;
}
