package com.cts.model;
 
import java.time.LocalDate;
 
 
import jakarta.persistence.Column;

import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;
 
@Entity

@Table(name="fine")

@Data

@AllArgsConstructor
@NoArgsConstructor

public class Fine {



	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name="fine_id")

	private int fineId;

	@ManyToOne

	@JoinColumn(name="member_id")

	private Member member;

	private double amount;

	private String status;

	@Column(name="transaction_date")
	private LocalDate transactionDate;
	
	private LocalDate paymentDate;

	@OneToOne
	@JoinColumn(name="borrow_id")
	private BorrowTransaction borrowTransaction;
	




}

 