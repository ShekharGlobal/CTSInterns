package com.cts.controller;

import com.cts.dto.MemberRequest;
import com.cts.model.Member;
import com.cts.repository.MemberRepository;
import com.cts.service.MemberService;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;

import lombok.extern.slf4j.Slf4j;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/members")
@Slf4j
public class MemberController {

    @Autowired
    private MemberService memberService;
    
    @Autowired
    private MemberRepository memberRepository;

    
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/all/{page}")
    public Page<Member> getAllMembers(@PathVariable int page) {
        log.info("Fetching all members");
        return memberService.getAllMembers(page);
    }
    
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/{memberId}")
    public ResponseEntity<Member> getMemberById(@PathVariable Long memberId) {
        log.info("Received request to fetch member with ID: {}", memberId);

        Member member = memberRepository.findById(memberId)
            .orElseThrow(() -> {
                log.warn("Member with ID '{}' not found", memberId);
                return new RuntimeException("Member not found");
            });

        log.info("Returning member: {}", member);
        return ResponseEntity.ok(member);
    }

    
    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("update/{memberId}")
    public Member updateMember(@PathVariable Long memberId, @RequestBody MemberRequest memberDTO) {
        log.info("Updating member with ID '{}'", memberId);
        return memberService.updateMember(memberId, memberDTO);
    }
    
    @PreAuthorize("hasAuthority('ADMIN')")
    @PatchMapping("update/{memberId}/status")
    public ResponseEntity<Member> updateMembershipStatus(@PathVariable Long memberId, @RequestParam String membershipStatus) {
        log.info("Received request to update membership status for ID: {}", memberId);
        
        Member existingMember = memberRepository.findById(memberId)
                .orElseThrow(() -> {
                    log.warn("Member with ID '{}' not found", memberId);
                    return new RuntimeException("Member not found");
                });

        existingMember.setMembershipStatus(membershipStatus);
        Member updatedMember = memberRepository.save(existingMember);

        log.info("Updated membership status for ID: {} to {}", memberId, updatedMember.getMembershipStatus());

        return ResponseEntity.ok(updatedMember);
    }


    
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("delete/{memberId}")
    public ResponseEntity<Map<String, String>> deleteMember(@PathVariable Long memberId) {
        log.info("Deleting member with ID '{}'", memberId);
        memberService.deleteMember(memberId);

        Map<String, String> response = new HashMap<>();
        response.put("message", "Member deleted successfully!");

        return ResponseEntity.ok(response); // ✅ Returns JSON object instead of plain text
    }

}
