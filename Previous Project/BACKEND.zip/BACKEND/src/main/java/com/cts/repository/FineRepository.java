package com.cts.repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.model.BorrowTransaction;
import com.cts.model.Fine;
import com.cts.model.Member;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface FineRepository extends JpaRepository<Fine, Integer> {
	boolean existsByMemberAndTransactionDateAndAmount(Member member, LocalDate transactionDate, double amount);
	List<Fine> findByStatus(String status);
	Fine findByMemberAndTransactionDate(Member member, LocalDate date);
	Optional<Fine> findByMemberAndStatus(Member member, String status);
	Optional<Fine> findByMemberAndBorrowTransactionAndStatus(Member member, BorrowTransaction borrow, String string);
	List<Fine> findByMember(Member member);
	Page<Fine> findByMemberName(String name, Pageable pageable);
}
