package com.cts.repository;

import com.cts.model.Admin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<Admin, Long> {

	Admin findByEmail(String email);
}
