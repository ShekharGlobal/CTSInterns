package com.cts.exception;

public class InvalidDateFormatException  extends RuntimeException {
	public InvalidDateFormatException() {
		super("Invalid date format. Please give the data in dd-MM-yyyy");
	}
}
