package com.cts.repository;

import com.cts.model.Book;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
    boolean existsByIsbn(String isbn);

	Page<Book> findByTitle(String title,Pageable pageable);

	Page<Book> findByAuthor(String author,Pageable pageable);

	Page<Book> findByIsbn(String isbn,Pageable pageable);

	Page<Book> findByYearPublished(int year,Pageable pageable);

	Page<Book> findByGenre(String genre,Pageable pageable);
	
	Page<Book> findAll(Pageable pageable);
	
	List<Book> findByTitle(String title);

	Optional<Book> findFirstByTitleAndStatus(String title, String status);
	
	List<Book> findByTitleAndStatus(String bookTitle, String string);
	
	 List<Book> findByTitleIgnoreCase(String title);
	    List<Book> findByTitleContainingIgnoreCase(String title);

		List<Book> findByIsbnAndStatus(String isbn, String string);
}