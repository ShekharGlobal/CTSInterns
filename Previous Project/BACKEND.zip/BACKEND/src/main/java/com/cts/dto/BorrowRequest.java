package com.cts.dto;

import java.time.LocalDate;

import com.cts.model.Book;
import com.cts.model.Member;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*
 *  @Data -> Lombok annotation that generates the boilerplate code 
 *  		Getters and Setters, toString(), equals() and hashCode()
 *  
 *  @NoArgsConstructor -> generates no argument constructor
 *  
 *  @AllArgsConstructor -> generates all argument constructor
 */

@Data
@NoArgsConstructor
@AllArgsConstructor
public class BorrowRequest {
	
	private Book book;
	private Member member;
	private LocalDate borrowDate;
	private LocalDate returnDate;
	private String status;
	
}
