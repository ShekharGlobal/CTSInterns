package com.cts.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.data.domain.Page;

import com.cts.model.BorrowTransaction;
import com.cts.service.BorrowService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class BorrowController {

	@Autowired
	private BorrowService borrowService;
	 @PreAuthorize("hasAuthority('MEMBER')")
	 @PostMapping("/borrow/{title}/{name}")
	public ResponseEntity<?> borrowBook(@PathVariable String title,@PathVariable String name){
		BorrowTransaction borrowTransaction = borrowService.borrowBookByTitle(title,name);

		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Messages", "Book borrowed successfully!");
		response.put("BorrowId", borrowTransaction.getBorrowId());
		response.put("MemberName", borrowTransaction.getMember().getName());
		response.put("BookTitle", borrowTransaction.getBook().getTitle());
		response.put("BorrowDate", borrowTransaction.getBorrowDate());
		response.put("ReturnDate", borrowTransaction.getReturnDate());

		return new ResponseEntity<>(response,HttpStatus.CREATED);
	}
    @PreAuthorize("hasAuthority('MEMBER')")
	@PostMapping("/return/{title}/{name}")
	public ResponseEntity<?> returnBook(@PathVariable String title, @PathVariable String name) {
		BorrowTransaction returnTransaction = borrowService.returnBookByTitleAndName(title, name);
		Map<String, Object> response = new HashMap<String, Object>();
		response.put("Messages", "Book returned successfully!");
		response.put("BorrowId", returnTransaction.getBorrowId());
		response.put("MemberName", returnTransaction.getMember().getName());
		response.put("BookTitle", returnTransaction.getBook().getTitle());
		response.put("BorrowDate", returnTransaction.getBorrowDate());
		response.put("ReturnDate", returnTransaction.getBookReturnOn());

		return new ResponseEntity<>(response, HttpStatus.OK);
	}
    @PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/borrow/all/{page}")
	public Page<BorrowTransaction> getAllBorrowDetails(@PathVariable int page) {
		return borrowService.getAllDetails(page);
	}

	@GetMapping("/borrow/{id}/{page}")
	public BorrowTransaction getBorrowById(@PathVariable int id) {
		return borrowService.getBorrowById(id);
	}
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/borrow/{status}/{page}")
		public ResponseEntity<Page<BorrowTransaction>> getByStatus(@PathVariable String status,@PathVariable int page) {
			return ResponseEntity.ok(borrowService.getByStatus(status,page));
	}
	
	 @PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/borrowDate/{borrowDate}/{page}")
	public ResponseEntity<Page<BorrowTransaction>> getByBorrowDate(@PathVariable String borrowDate,@PathVariable int page) {
		return ResponseEntity.ok(borrowService.getByBorrowDate(borrowDate,page));
	}
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/returnDate/{returnDate}")
	public ResponseEntity<Page<BorrowTransaction>> getByReturnDate(@PathVariable String returnDate,@PathVariable int page) {
		return ResponseEntity.ok(borrowService.getByReturnDate(returnDate,page));
	}
	@PreAuthorize("hasAuthority('ADMIN')")
	@DeleteMapping("/borrow/delete/{id}")
	public String deleteBorrowDetails(@PathVariable int id) {
		borrowService.deleteBorrowDetails(id);
		return "Borrow Id "+ id + " deleted successfully";
	}
	@PreAuthorize("hasAuthority('MEMBER')")
	@GetMapping("/borrow/history/{name}/{page}")
	public ResponseEntity<Page<BorrowTransaction>> getBorrowHistoryByMemberName(@PathVariable String name, @PathVariable int page) {
	    return ResponseEntity.ok(borrowService.getBorrowHistoryByMemberName(name, page));
	}
	@PreAuthorize("hasAuthority('ADMIN')")
	@GetMapping("/bookborrow/{title}/{page}")
	public ResponseEntity<Page<BorrowTransaction>> getBorrowHistoryByBookTitle(@PathVariable String title, @PathVariable int page) {
	    return ResponseEntity.ok(borrowService.getBorrowHistoryByBookTitle(title, page));
	}

}