package com.cts.service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.cts.exception.ResourceNotAvailableException;
import com.cts.model.BorrowTransaction;
import com.cts.model.Fine;
import com.cts.model.Member;
import com.cts.repository.BorrowRepository;
import com.cts.repository.FineRepository;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class FineService {

    @Autowired
    private FineRepository fineRepository;

    @Autowired
    private BorrowRepository borrowRepository;


    @Scheduled(cron = "59 08 10 * * ?")
    public void checkAndApplyFines() {
    	log.info("Checking and applying fines");
        List<BorrowTransaction> overdueBorrows = borrowRepository.findByStatusAndReturnDateBefore("borrowed", LocalDate.now());

        for (BorrowTransaction borrow : overdueBorrows) {
            Member member = borrow.getMember();
            LocalDate dueDate = borrow.getReturnDate();
            LocalDate currentDate = LocalDate.now();
            Optional<Fine> existingFineOpt = fineRepository.findByMemberAndBorrowTransactionAndStatus(member, borrow, "unpaid");

            if (currentDate.isAfter(dueDate)) {
                if (existingFineOpt.isPresent()) {
                    Fine existingFine = existingFineOpt.get();
                    existingFine.setAmount(calculateFine(dueDate, currentDate));
                    existingFine.setTransactionDate(currentDate); 
                    fineRepository.save(existingFine);
                } else {
                    Fine fine = new Fine();
                    fine.setMember(member);
                    fine.setStatus("unpaid");
                    fine.setTransactionDate(currentDate); 
                    fine.setAmount(calculateFine(dueDate, currentDate));
                    fine.setBorrowTransaction(borrow); 
                    fineRepository.save(fine);
                }
            }
        }
    }

    private double calculateFine(LocalDate dueDate, LocalDate currentDate) {
    	log.info("Calculating fines");
        long daysLate = ChronoUnit.DAYS.between(dueDate, currentDate);
        return daysLate * 5; 
    }

    public Page<Fine> getAllFines(int page) {
    	log.info("Fetching all the OVERDUES");
    	Pageable pageable = PageRequest.of(page, 10);
        return fineRepository.findAll(pageable);
    }

    public Fine getFineById(int id) {
    	log.info("Fetching fine details by fineId {}",id);
        return fineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotAvailableException("Fine not found with id: " + id));
    }

    public List<Fine> getFinesByMember(Member member) {
    	log.info("Fetching fine details by member {}",member);
        return fineRepository.findByMember(member);
    }
    
    public Fine updateFine(int id, Fine fineDetails) {
    	log.info("Updating fine details by fineId {}",id);
        Fine fine = fineRepository.findById(id)
                .orElseThrow(() -> new ResourceNotAvailableException("Fine not found with id: " + id));

        fine.setStatus(fineDetails.getStatus());
        fine.setAmount(fineDetails.getAmount());

        return fineRepository.save(fine);
    }

    public void deleteFine(int id) {
    	log.info("Delete fine details by fineId {}",id);
        fineRepository.deleteById(id);
    }
    
    public Page<Fine> getFineHistoryByMemberName(String name, int page) {
        Pageable pageable = PageRequest.of(page, 10);
        return fineRepository.findByMemberName(name, pageable);
    }

    public Fine payFine(int fineId) {
    	log.info("Paying fines by fineId {}",fineId);
        Fine fine = fineRepository.findById(fineId)
                .orElseThrow(() -> new ResourceNotAvailableException("Fine not found with id: " + fineId));

        BorrowTransaction borrowTransaction = fine.getBorrowTransaction();
        if (!"returned".equals(borrowTransaction.getStatus())) {
            throw new IllegalStateException("Please return the book and pay the fine.");
        }

        fine.setStatus("paid");
        fine.setPaymentDate(LocalDate.now());
        return fineRepository.save(fine);
    }
}
