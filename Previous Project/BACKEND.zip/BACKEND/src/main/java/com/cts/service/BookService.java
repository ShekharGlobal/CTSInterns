package com.cts.service;

import com.cts.dto.BookRequest;
import com.cts.exception.BookNotFoundException;
import com.cts.model.AvailableCopies;
import com.cts.model.Book;
import com.cts.repository.AvailableCopiesRepository;
import com.cts.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private AvailableCopiesRepository availableCopiesRepository;

    public String addBook(BookRequest request) {
    	
    	log.info("Adding Books");

        Book book = new Book();
        book.setTitle(request.getTitle());
        book.setAuthor(request.getAuthor());
        book.setGenre(request.getGenre());
        book.setIsbn(request.getIsbn());
        book.setYearPublished(request.getYearPublished());
        book.setStatus("available");
        bookRepository.save(book);


        AvailableCopies availableCopies = availableCopiesRepository.findById(request.getIsbn()).orElse(null);
        if (availableCopies != null) {
            availableCopies.setCount(availableCopies.getCount() + 1);
            availableCopies.setBookTitle(book.getTitle());
            availableCopiesRepository.save(availableCopies);
            return "Book already exists. Incremented available copies count.";
        } else {

            availableCopies = new AvailableCopies();
            availableCopies.setIsbn(request.getIsbn());
            availableCopies.setCount(1);
            availableCopies.setBookTitle(book.getTitle());
            availableCopiesRepository.save(availableCopies);
            return "Book added successfully!";

        }

    }

    public Page<Book> getAllBooks(int page) {
    	log.info("Fetching all details");
    	Pageable pageable = PageRequest.of(page, 50, Sort.by(Sort.Direction.ASC, "title"));
        return bookRepository.findAll(pageable);
    }

    public String deleteBookById(Long id) {
        log.info("Attempting to delete book with ID '{}'", id);

        Optional<Book> bookOptional = bookRepository.findById(id);
        if (bookOptional.isEmpty()) {
            log.warn("Book with ID '{}' not found", id);
            return "Book not found!";
        }

        Book book = bookOptional.get();
        String isbn = book.getIsbn();

        // ✅ Check if the book is available before deleting
        if (!book.getStatus().equalsIgnoreCase("available")) {
            log.warn("Book '{}' cannot be deleted as it is currently borrowed.", book.getTitle());
            return "Book cannot be deleted because it is currently borrowed.";
        }

        // ✅ Get count of available books with the same ISBN
        List<Book> availableBooksWithSameIsbn = bookRepository.findByIsbnAndStatus(isbn, "available");

        // ✅ If only **one** copy is available, delete it fully
        if (availableBooksWithSameIsbn.size() == 1) {
            availableCopiesRepository.findByIsbn(isbn).ifPresent(availableCopies -> {
                availableCopiesRepository.delete(availableCopies);
                log.info("Deleted available copies entry for ISBN '{}'", isbn);
            });

            bookRepository.deleteById(id);
            log.info("Book '{}' deleted successfully!", book.getTitle());
            return "Book deleted successfully!";
        } else {
            // ✅ If multiple available copies exist, just reduce count
            availableCopiesRepository.findByIsbn(isbn).ifPresent(availableCopies -> {
                availableCopies.setCount(availableCopies.getCount() - 1);
                availableCopiesRepository.save(availableCopies);
                log.info("Decreased available copies count for ISBN '{}'. Remaining copies: {}", isbn, availableCopies.getCount());
            });

            bookRepository.deleteById(id);
            log.info("One available copy of '{}' deleted, but other copies remain.", book.getTitle());
            return "One available copy deleted, but other copies remain.";
        }
    }

    public String updateBooksByTitle(String title, Book updatedBook) {
        title = title.trim();
        log.info("Updating all books with title '{}'", title);

        List<Book> books = bookRepository.findByTitleIgnoreCase(title);

        if (books.isEmpty()) {
            log.warn("No books found with title '{}'", title);
            throw new BookNotFoundException("No books found with the given title");
        }

        String newIsbn = updatedBook.getIsbn();

        for (Book book : books) {
            String oldIsbn = book.getIsbn();

            // Update book details
            book.setTitle(updatedBook.getTitle());
            book.setAuthor(updatedBook.getAuthor());
            book.setStatus("available");
            book.setIsbn(newIsbn);
            bookRepository.save(book);
            log.info("Book '{}' updated successfully with new ISBN '{}'", book.getTitle(), newIsbn);

            // ✅ ISBN Change Handling & Count Fixes
            if (!oldIsbn.equals(newIsbn)) {
                log.info("ISBN change detected: '{}' → '{}'", oldIsbn, newIsbn);

                // ✅ Reduce count for old ISBN, ensuring it doesn't go negative
                availableCopiesRepository.findByIsbn(oldIsbn).ifPresent(oldCopies -> {
                    int currentCount = oldCopies.getCount();
                    int booksCount = books.size(); // ✅ Correct number of affected books
                    int adjustedCount = Math.max(0, currentCount - booksCount);
                    oldCopies.setCount(adjustedCount);
                    availableCopiesRepository.save(oldCopies);
                    log.info("Updated available copies for old ISBN '{}': New count = {}", oldIsbn, oldCopies.getCount());
                    if (adjustedCount == 0) {
                        availableCopiesRepository.delete(oldCopies);
                        log.info("Deleted old ISBN '{}' as no copies remain", oldIsbn);
                    }
                });

                // ✅ Replace old ISBN with new ISBN instead of creating a duplicate row
                AvailableCopies newCopies = availableCopiesRepository.findByIsbn(newIsbn)
                    .orElse(new AvailableCopies(newIsbn, 0, title)); // ✅ Ensure title is stored
                int correctNewCount = books.size(); // ✅ Count should reflect updated books
                newCopies.setCount(correctNewCount);
                newCopies.setBookTitle(title);
                availableCopiesRepository.save(newCopies);
                log.info("Updated available copies for new ISBN '{}': New count = {}", newIsbn, newCopies.getCount());
            }
        }

        // ✅ Final Debugging Steps
        log.info("Final Check: Total books updated = {}", books.size());

        return "Books updated successfully!";
    }


    public Page<Book> getBookByIsbn(String isbn,int page) {
    	log.info("Book fetched by ISBN");

    	Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "title"));
        Page <Book> book = bookRepository.findByIsbn(isbn,pageable);
        if (book.isEmpty()) {
            throw new BookNotFoundException("No book found with ISBN: " + isbn);
        }
        return book;
    }

    public Page<Book> getBooksByAuthor(String author, int page) {
    	log.info("Books fetched by author");
    	Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "title"));
    	
        Page<Book> books = bookRepository.findByAuthor(author,pageable);
        if (books.isEmpty()) {
            throw new BookNotFoundException("No books found by author: " + author);
        }
        return books;
    }

    public Page<Book> getBooksByTitle(String title,int page) {
    	log.info("Books fetched by Title");

    	Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "title"));
        Page<Book> books = bookRepository.findByTitle(title,pageable);
        if (books.isEmpty()) {
            throw new BookNotFoundException("No books found with title: " + title);
        }
        return books;
    }

    public Page <Book> getBooksByYearPublished(int year,int page) {
    	log.info("Books fetched by Year published");
    	Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "title"));
        Page<Book> books = bookRepository.findByYearPublished(year,pageable);
        if (books.isEmpty()) {
            throw new BookNotFoundException("No books found published in year: " + year);
        }
        return books;
    }

    public Page<Book> getBooksByGenre(String genre,int page) {
    	log.info("Books fetched by genre");
    	Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "title"));
        Page<Book> books = bookRepository.findByGenre(genre,pageable);
        
        if (books.isEmpty()) {
            throw new BookNotFoundException("No books found in genre: " + genre);
        }
        return books;
    }

}