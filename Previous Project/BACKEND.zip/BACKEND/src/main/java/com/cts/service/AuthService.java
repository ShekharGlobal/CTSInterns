package com.cts.service;

import com.cts.dto.LoginRequest;
import com.cts.model.Admin;
import com.cts.model.Member;
import com.cts.repository.AdminRepository;
import com.cts.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@Slf4j
public class AuthService {

    @Autowired
    private AdminRepository adminRepository;
    @Autowired
    private MemberRepository memberRepository;

    
    @Autowired
    private PasswordEncoder passwordEncoder;

    public boolean authenticateAdmin(LoginRequest loginRequest) {
        log.info("Login Admin {}", loginRequest.getEmail());
        Admin admin = adminRepository.findByEmail(loginRequest.getEmail());

        return admin != null &&
               passwordEncoder.matches(loginRequest.getPassword(), admin.getPassword());
    }

    public boolean authenticateMember(LoginRequest loginRequest) {
        log.info("Login Member {}", loginRequest.getEmail());

        return memberRepository.findByEmail(loginRequest.getEmail())
            .map(member -> passwordEncoder.matches(loginRequest.getPassword(), member.getPassword())) // ✅ Encrypted check
            .orElse(false);
    }

    public Admin getAdminByEmail(String email) {
        log.info("Fetching the admin by email");
        return adminRepository.findByEmail(email);
    }

    public Optional<Member> getMemberByEmail(String email) {
        log.info("Fetching the Member by email");
        return memberRepository.findByEmail(email);
    }
}