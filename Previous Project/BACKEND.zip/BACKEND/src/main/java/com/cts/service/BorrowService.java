package com.cts.service;
 
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.exception.BookNotFoundException;
import com.cts.exception.LimitExceededException;
import com.cts.exception.MemberNotFoundException;
import com.cts.exception.ResourceNotAvailableException;
import com.cts.model.AvailableCopies;
import com.cts.model.Book;
import com.cts.model.BorrowTransaction;
import com.cts.model.Member;
import com.cts.repository.AvailableCopiesRepository;
import com.cts.repository.BookRepository;
import com.cts.repository.BorrowRepository;
import com.cts.repository.MemberRepository;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BorrowService {
 
    @Autowired
    private BorrowRepository borrowRepository;
 
    @Autowired
    private BookRepository bookRepository;
 
    @Autowired
    private MemberRepository memberRepository;
 
    @Autowired
    private AvailableCopiesRepository availableCopiesRepository;
 
  
    public BorrowTransaction borrowBookByTitle(String title, String name) {
       try {
    	log.info("Borrowing book with title '{}' for member '{}'", title, name);

        Member member = memberRepository.findByName(name)
                .orElseThrow(() -> {
                    log.warn("Member '{}' not found", name);
                    return new MemberNotFoundException("Member not found");
                });

        List<BorrowTransaction> activeBorrows = borrowRepository.findByMemberNameAndStatus(name, "borrowed");

        if (activeBorrows.size() >= 3) {
            log.warn("Borrow limit exceeded for member '{}'", name);
            throw new LimitExceededException("Borrow limit exceeded. Member can borrow up to 3 books.");
        }

        Book book = bookRepository.findFirstByTitleAndStatus(title, "available")
                .orElseThrow(() -> {
                    log.warn("No available copy found for title '{}'", title);
                    return new BookNotFoundException("No available copy of this title");
                });

        AvailableCopies count = availableCopiesRepository.findByIsbn(book.getIsbn())
                .orElseThrow(() -> {
                    log.warn("Available copy not found for ISBN '{}'", book.getIsbn());
                    return new BookNotFoundException("Available copy not found");
                });

        if (count.getCount() <= 0) {
            log.warn("No copies available to borrow for ISBN '{}'", book.getIsbn());
            throw new BookNotFoundException("No copies available to borrow");
        }

        book.setStatus("borrowed");
        bookRepository.save(book);
        count.setCount(count.getCount() - 1);
        availableCopiesRepository.save(count);
        BorrowTransaction borrowTransaction = new BorrowTransaction();
        borrowTransaction.setBook(book);
        borrowTransaction.setMember(member);
        borrowTransaction.setStatus("borrowed");
        borrowTransaction.setBorrowDate(LocalDate.now());
        borrowTransaction.setReturnDate(LocalDate.now().plusDays(14));
        borrowTransaction.setBookReturnOn(null);

        BorrowTransaction savedTransaction = borrowRepository.save(borrowTransaction);
        log.info("Book '{}' successfully borrowed by '{}'", title, name);

        return savedTransaction;
       }
       catch (Exception e) {
    	   log.error("Exception during borrowing: {}", e.getMessage(), e); // ✅ Improved logging
           throw new RuntimeException("Borrowing failed due to: " + e.getMessage()); // ✅ Ensure exception is propagated
       }
    }

 
    public BorrowTransaction returnBookByTitleAndName(String title, String name) {
    	log.info("Returning book with title '{}' for member '{}'", title, name);
    	
        List<BorrowTransaction> borrowHistory = borrowRepository.findByMemberNameAndBookTitleAndStatus(name, title, "borrowed");
 
        if (borrowHistory.isEmpty()) {
        	log.warn("No books titled {} is borrowed by {}",title,name);
            throw new ResourceNotAvailableException("No active borrow record found");
        }
 
        BorrowTransaction borrowTransaction = borrowHistory.get(0);
        
        borrowTransaction.setStatus("returned");
        borrowTransaction.setReturnDate(borrowTransaction.getReturnDate());;
        borrowTransaction.setBookReturnOn(LocalDate.now());
        borrowRepository.save(borrowTransaction);
 
        Book book = borrowTransaction.getBook();
        book.setStatus("available");
        bookRepository.save(book);
 
        AvailableCopies count = availableCopiesRepository.findByIsbn(book.getIsbn())
        		.orElseThrow(() -> {
                    log.warn("Available copy info not found for ISBN '{}'", book.getIsbn());
                    return new BookNotFoundException("Available copy info not found");
                });   
        
        count.setCount(count.getCount() + 1);
        availableCopiesRepository.save(count);
        log.info("Book '{}' successfully returned by '{}'", title, name);
        return borrowTransaction;
    }
 
    public Page<BorrowTransaction> getAllDetails(int page) {
    	log.info("Fetching all details");
    	Pageable pageable = PageRequest.of(page, 9, Sort.by(Sort.Direction.ASC, "borrowDate"));
        return borrowRepository.findAll(pageable);
        
    }
 
    public BorrowTransaction getBorrowById(int id) {
    	log.info("Fetching Borrow details by Id {}",id);
        return borrowRepository.findById(id)
        		.orElseThrow(() -> {
                    log.warn("Borrow transaction is not found the Borrow Id - '{}'", id);
                    return new ResourceNotAvailableException("Borrow transaction is not found.");
                });  
    }
 
    public Page<BorrowTransaction> getByStatus(String status,int page) {
    	log.info("Fetching borrow details by Status {}",status);
    	 Pageable pageable = PageRequest.of(page, 3, Sort.by(Sort.Direction.ASC, "borrowDate"));
         return borrowRepository.findByStatus(status, pageable);
    }

    
    public Page<BorrowTransaction> getByBorrowDate(String borrowDate, int page) {
    	log.info("Fetching borrow details by BorrowDate {}",borrowDate);
        LocalDate date = LocalDate.parse(borrowDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        Pageable pageable = PageRequest.of(page, 3,Sort.by(Sort.Direction.ASC, "status"));
        return borrowRepository.findByBorrowDate(date, pageable);
    }

    public Page<BorrowTransaction> getByReturnDate(String returnDate, int page) {
    	log.info("Fetching borrow details by ReturnDate {}",returnDate);
        LocalDate date = LocalDate.parse(returnDate, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
        Pageable pageable = PageRequest.of(page, 3,Sort.by(Sort.Direction.ASC, "status"));
        return borrowRepository.findByReturnDate(date, pageable);
    }

    public void deleteBorrowDetails(int id) {
    	log.info("Deleting borrow details by BorrowId {}",id);
        borrowRepository.deleteById(id);
    }
    public Page<BorrowTransaction> getBorrowHistoryByMemberName(String name, int page) {
        Pageable pageable = PageRequest.of(page, 10,Sort.by(Sort.Direction.DESC, "borrowDate"));
        return borrowRepository.findByMemberName(name, pageable);
    }
    
    public Page<BorrowTransaction> getBorrowHistoryByBookTitle(String title, int page) {
        Pageable pageable = PageRequest.of(page, 3,Sort.by(Sort.Direction.ASC, "borrowDate"));
        return borrowRepository.findByBookTitle(title, pageable);
    }
}
 
 
