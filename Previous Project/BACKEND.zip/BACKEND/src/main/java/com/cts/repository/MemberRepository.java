package com.cts.repository;

import com.cts.model.Member;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long> {
   Optional <Member> findByEmail(String email);
    Optional<Member> findByMemberId(Long memberId);
    Optional<Member> findByName(String memberName);
    Page<Member> findAll(Pageable pageable);
    boolean existsByEmail(String email); 
    boolean existsByPhone(String phone);
   
}
