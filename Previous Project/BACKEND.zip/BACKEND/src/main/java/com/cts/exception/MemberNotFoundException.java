package com.cts.exception;

public class MemberNotFoundException extends RuntimeException{
	public MemberNotFoundException(String borrowDate) {
		super("No details are found in date : " + borrowDate);
	}
}
