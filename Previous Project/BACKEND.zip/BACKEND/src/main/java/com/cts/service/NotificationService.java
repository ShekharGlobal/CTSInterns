package com.cts.service;

import com.cts.model.BorrowTransaction;
import com.cts.model.Fine;
import com.cts.model.Member;
import com.cts.model.Notification;
import com.cts.repository.BorrowRepository;
import com.cts.repository.FineRepository;
import com.cts.repository.NotificationRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class NotificationService {

    @Autowired
    private BorrowRepository borrowRepository;

    @Autowired
    private FineRepository fineRepository;

    @Autowired 
    private EmailService emailService;

    @Autowired
    private NotificationRepository notificationRepository;

    @Scheduled(cron = "0 01 13 * * ?") 
    public void sendReturnReminders() {
        LocalDate tomorrow = LocalDate.now().plusDays(1);
        LocalDate today = LocalDate.now();
        List<BorrowTransaction> dueTomorrow = borrowRepository.findByReturnDateAndStatus(tomorrow, "borrowed");
        List<BorrowTransaction> dueToday = borrowRepository.findByReturnDateAndStatus(today, "borrowed");

        for (BorrowTransaction borrow : dueTomorrow) {
            Member member = borrow.getMember();
            String subject = "Reminder: Book Return Due Tomorrow";
            String msg = String.format("Dear Member,\n\nBook: %s is due for return tomorrow.\n\nThank you,\nLibrary Team", borrow.getBook().getTitle());
            sentNotificationEmail(member.getEmail(), subject, msg);
        }

        for (BorrowTransaction borrow : dueToday) {
            Member member = borrow.getMember();
            String subject = "Reminder: Book Return Due Today";
            String msg = String.format("Dear Member,\n\nBook: %s is due for return today.\n\nThank you,\nLibrary Team", borrow.getBook().getTitle());
            sentNotificationEmail(member.getEmail(), subject, msg);
        }
    }

    @Scheduled(cron = "0 01 13 * * ?") 
    public void sendOverdueFineNotifications() {
        List<Fine> allFines = fineRepository.findAll();

        allFines.stream()
                .filter(f -> f.getStatus().equals("unpaid"))
                .map(Fine::getMember)
                .distinct()
                .forEach(member -> {
                    List<Fine> memberFines = fineRepository.findByMember(member);
                    StringBuilder messageBuilder = new StringBuilder("Dear Member,\n\nThe following books have unpaid fines:\n\n");
                    double totalFine = 0;

                    for (Fine fine : memberFines) {
                        if ("unpaid".equals(fine.getStatus())) {
                            BorrowTransaction bt = fine.getBorrowTransaction();
                            String status = bt.getStatus();
                            messageBuilder.append(String.format("Book: %s, Fine: %.0f, %s\n",
                                    bt.getBook().getTitle(), fine.getAmount(), status.equals("returned") ? "Returned" : "Not Returned"));
                            totalFine += fine.getAmount();
                        }
                    }

                    messageBuilder.append(String.format("\nTotal fine: %.0f\n\nPlease take necessary action.\n\nLibrary Team", totalFine));
                    sentNotificationEmail(member.getEmail(), "Overdue Book and Unpaid Fine Notification", messageBuilder.toString());
                });
    }

    public void sentNotificationEmail(String to, String subject, String body) {
    	
        emailService.sendSimpleMail(to, subject, body);
        Notification notification = new Notification();
        notification.setEmail(to);
        notification.setSubject(subject);
        notification.setMessage(body);
        notification.setSentAt(LocalDateTime.now());
        notification.setSuccess(true);
        notificationRepository.save(notification);
    }
    
    public Page<Notification> getAllNotification(int page){
    	log.info("Fetching all the notifications");
    	Pageable pageable = PageRequest.of(page, 3);
    	return notificationRepository.findAll(pageable);
    }
    
	public Page<Notification> getByEmail(String email, int page) {
		log.info("Fetching all data by email");
		Pageable pageable = PageRequest.of(page, 3);
		return notificationRepository.findByEmail(email, pageable);
	}
}
