package com.cts.service;

import com.cts.model.Admin;
import com.cts.repository.AdminRepository;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AdminService {
    @Autowired
    private AdminRepository adminRepository;

    public Admin findByEmail(String email) {
    	log.info("Fetching admin details by email {}",email);
        return adminRepository.findByEmail(email);
    }
}
