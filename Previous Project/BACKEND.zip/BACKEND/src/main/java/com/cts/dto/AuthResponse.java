package com.cts.dto;

public class AuthResponse {
    private String token;

    public AuthResponse(String token, String string) {
        this.token = token;
    }

    public String getToken() {
        return token;
    }
}

