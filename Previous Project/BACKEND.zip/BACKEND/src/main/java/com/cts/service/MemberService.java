package com.cts.service;

import com.cts.dto.MemberRequest;
import com.cts.model.Member;
import com.cts.repository.MemberRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import lombok.extern.slf4j.Slf4j;


@Service
@Slf4j
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    	public Member registerMember(MemberRequest memberDTO) {
    	    log.info("Registering member with email '{}'", memberDTO.getEmail());

    	    if (memberRepository.existsByEmail(memberDTO.getEmail())) {
    	        throw new RuntimeException("Email already exists!");
    	    }

    	    if (memberRepository.existsByPhone(memberDTO.getPhone())) {
    	        throw new RuntimeException("Phone number already exists!");
    	    }

    	    Member member = new Member();
    	    member.setName(memberDTO.getName());
    	    member.setEmail(memberDTO.getEmail());
    	    member.setPhone(memberDTO.getPhone());
    	    member.setAddress(memberDTO.getAddress());
    	    member.setPassword(memberDTO.getPassword());
    	    member.setMembershipStatus("Active");

    	    return memberRepository.save(member);
    	}

   

    public Page<Member> getAllMembers(int page) {
        log.info("Fetching all members");
        Pageable pageable = PageRequest.of(page, 5);	
        return memberRepository.findAll(pageable);
    }

    public Member updateMember(Long memberId, MemberRequest memberDTO) {
        log.info("Updating member with ID '{}'", memberId);
        Member existingMember = memberRepository.findById(memberId)
                .orElseThrow(() -> {
                    log.warn("Member with ID '{}' not found", memberId);
                    return new RuntimeException("Member not found");
                });

        existingMember.setName(memberDTO.getName());
        existingMember.setEmail(memberDTO.getEmail());
        existingMember.setPhone(memberDTO.getPhone());
        existingMember.setAddress(memberDTO.getAddress());
        existingMember.setMembershipStatus(memberDTO.getMembershipStatus());
        return memberRepository.save(existingMember);
    }

    public Member updateMembershipStatus(Long memberId, String membershipStatus) {
        log.info("Updating membership status for member with ID '{}'", memberId);
        Member existingMember = memberRepository.findById(memberId)
                .orElseThrow(() -> {
                    log.warn("Member with ID '{}' not found", memberId);
                    return new RuntimeException("Member not found");
                });

        existingMember.setMembershipStatus(membershipStatus);
        return memberRepository.save(existingMember);
    }

    public void deleteMember(Long memberId) {
        log.info("Deleting member with ID '{}'", memberId);
        memberRepository.deleteById(memberId);
    }
}