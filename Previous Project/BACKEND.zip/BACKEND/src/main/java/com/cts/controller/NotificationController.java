package com.cts.controller;

import com.cts.model.Notification;
import com.cts.service.NotificationService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping("/all/{page}")
    public Page<Notification> getAllNotification(@PathVariable int page) {
        return notificationService.getAllNotification(page);
    }
    
    
    @GetMapping("/email/{email}/{page}")
    public Page<Notification> getByEmail(@PathVariable String email, @PathVariable int page){
    	return notificationService.getByEmail(email, page);
    }
}
