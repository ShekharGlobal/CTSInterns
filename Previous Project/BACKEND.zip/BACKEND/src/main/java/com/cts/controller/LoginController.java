package com.cts.controller;

import com.cts.model.Member;
import com.cts.model.Login;
import com.cts.service.LoginService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/login")
public class LoginController {
    @Autowired
    private LoginService loginService;
    
    public String loginUser(@RequestBody Member member) {
        loginService.saveLogin(member.getMemberId(), member.getEmail(), null);
        return "Login recorded successfully!";
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @GetMapping("/all/{page}")
    public Page<Login> getAll(@PathVariable int page){
    	return loginService.getAll(page);
    }
}
