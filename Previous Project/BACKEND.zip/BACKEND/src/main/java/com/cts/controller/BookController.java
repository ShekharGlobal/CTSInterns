package com.cts.controller;
 
import com.cts.dto.BookRequest;
import com.cts.model.AvailableCopies;
import com.cts.model.Book;
import com.cts.repository.AvailableCopiesRepository;
import com.cts.service.BookService;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

 
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/books")
public class BookController {
 
    @Autowired
    private BookService bookService;
    
    @Autowired
    private AvailableCopiesRepository availableCopiesRepository;
    
    /*
     * {
	    "title":"Java",
	    "author":"James",
	    "genre":"Programming",
	    "isbn":"1234567890",
	    "yearPublished":1995
		}
		{
	    "title":"C",
	    "author":"Dennis",
	    "genre":"Programming",
	    "isbn":"1234567891",
	    "yearPublished":1989
}
		{
	    "title":"Python",
	    "author":"Guido",
	    "genre":"Programming",
	    "isbn":"1234567892",
	    "yearPublished":1991
		}
     */
   @PreAuthorize("hasAuthority('ADMIN')")
    @PostMapping("/add")
    public Map<String, String> addBook(@RequestBody BookRequest book) {
        String message = bookService.addBook(book);
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return response;  // ✅ Return a proper JSON response
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/all/{page}")
    public Page<Book> listAllBooks(@PathVariable int page) {
        return bookService.getAllBooks(page);
    }
    @PreAuthorize("hasAuthority('ADMIN')")
    @PutMapping("/update/{title}")
    public ResponseEntity<Map<String, String>> updateBooksByTitle(@PathVariable String title, @RequestBody Book updatedBook) {

        String message = bookService.updateBooksByTitle(title, updatedBook);

        Map<String, String> response = new HashMap<>();
        response.put("message", message);

        return ResponseEntity.ok(response);
    }
    
    @GetMapping("/copies")
    public List<AvailableCopies> getAvailableBooks(){
    	return availableCopiesRepository.findAll();
    }

 
    @PreAuthorize("hasAuthority('ADMIN')")
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<Map<String, String>> deleteBook(@PathVariable Long id) {
        String message = bookService.deleteBookById(id);
        Map<String, String> response = new HashMap<>();
        response.put("message", message);
        return ResponseEntity.ok(response); // ✅ Ensure response is valid JSON
    }
    
    @GetMapping("/isbn/{isbn}/{page}")
    public Page<Book> getBookByIsbn(@PathVariable String isbn,@PathVariable int page) {
        return bookService.getBookByIsbn(isbn,page);
    }
 
    @GetMapping("/author/{author}/{page}")
    public Page<Book> getBooksByAuthor(@PathVariable String author,@PathVariable int page) {
        return bookService.getBooksByAuthor(author,page);
    }
 
    @GetMapping("/title/{title}/{page}")
    public Page<Book> getBooksByTitle(@PathVariable String title,@PathVariable int page) {
        return bookService.getBooksByTitle(title,page);
    }
 
    @GetMapping("/year/{year}/{page}")
    public Page<Book> getBooksByYearPublished(@PathVariable int year,@PathVariable int page) {
        return bookService.getBooksByYearPublished(year,page);
    }
 
    @GetMapping("/genre/{genre}/{page}")
    public Page<Book> getBooksByGenre(@PathVariable String genre,@PathVariable int page) {
        return bookService.getBooksByGenre(genre,page);
    }
}