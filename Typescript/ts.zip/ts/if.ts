let x:number=100, y:number=40;


if(x<y){

    console.log('x is less than y');
}

else{

    console.log('x is greate than y')
}