function multiply(a: number, b: number = 2): number {
    return a * b;
}
console.log(multiply(5)); // Output: 10
console.log(multiply(5, 3)); // Output: 15
