const name = "Venkat"; // Cannot be reassigned
name = "Hema"; 
name2 = "Raj"; // ✅ Works because 'var' allows reassignment
console.log(name); // Output: Raj
