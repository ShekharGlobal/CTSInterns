function testVar() {
    var x = 10;
    if (true) {
        var x = 20; // Re-declared inside the same function
        console.log(x); // Output: 20
    }
    console.log(x); // Output: 20 (var is function-scoped)
}
testVar();
