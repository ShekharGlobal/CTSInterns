let count = 0;
while (count < 5) {
    console.log(`Count is ${count}`);
    count++;
}
