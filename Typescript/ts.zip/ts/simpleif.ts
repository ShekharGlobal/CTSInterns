let isEven = (num % 2 === 0) ? "Even" : "Odd";
console.log(isEven);
