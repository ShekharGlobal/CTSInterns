const add = (x: number, y: number): number => x + y;
console.log(add(4, 6)); // Output: 10

function add2(x: number, y: number): number {
    return x + y;
}

console.log(add2(4, 6)); // Output: 10
