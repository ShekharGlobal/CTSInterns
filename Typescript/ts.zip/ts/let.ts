function testLet() {
    let y = 10;
    if (true) {
        let y = 20; // Block-scoped
        console.log(y); // Output: 20
    }
    console.log(y); // Output: 10 (let is block-scoped)
}
testLet();
