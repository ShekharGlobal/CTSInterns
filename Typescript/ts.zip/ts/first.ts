var greet : string = "Welcome to";
var orgName : string = "CTS!";
console.log(greet+ " "+orgName);