let marks=96;

if(marks<50){
console.log("fail");

}

else if(marks>=50 && marks<60){
    console.log("poor")
}

else if(marks>=90 && marks<100){
    console.log("Excellent")
}