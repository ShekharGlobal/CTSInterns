//let mytuple:[number, boolean, string];

let mytuple2=[100, true, "ts is cool"];
console.log(mytuple2);