function testConst() {
    const z = 10;
    if (true) {
        const z = 20; // Block-scoped
        console.log(z); // Output: 20
    }
    console.log(z); // Output: 10
}
testConst();
