let isDone: boolean = true;
console.log(`Is done: ${isDone}`);