let num = 0;
do {
    console.log(`Num is ${num}`);
    num++;
} while (num < 5);
