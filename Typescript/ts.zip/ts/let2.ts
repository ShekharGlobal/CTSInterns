let age = 25;
age = 30; // ✅ Allowed
console.log(age); // Output: 30
