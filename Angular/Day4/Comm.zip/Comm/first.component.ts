// first.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-first',
  templateUrl: './first.component.html',
  styleUrls: ['./first.component.css']
})
export class FirstComponent {
  // Message to send to the SecondComponent
  message: string = 'Hello from First Component!';
  
  // Message received from SecondComponent/child
  receivedMessage: string = '';

  // Method to receive the message from SecondComponent
  receiveMessage(message: string) {
    this.receivedMessage = message;
  }

  sendMessageToSecond() {
    this.message = 'Message updated by First Component';
  }
}
