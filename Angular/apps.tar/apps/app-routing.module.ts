import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TrainListComponent } from './train/train-list/train-list.component';
import { TrainFormComponent } from './train-form/train-form.component';
import { RouteComponent } from './train/route/route.component';
import { TrainUpdateComponent } from './train/train-update/train-update.component';

const routes: Routes = [
  { path: 'trains', component: TrainListComponent },
  { path: 'add-train', component: TrainFormComponent },
  {path: 'routes', component:RouteComponent},
  {path:'update-train/:id', component:TrainUpdateComponent},
  { path: '', redirectTo: 'trains', pathMatch: 'full' }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
