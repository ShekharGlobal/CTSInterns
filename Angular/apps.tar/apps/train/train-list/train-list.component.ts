import { Component, OnInit } from '@angular/core';
import { Train } from 'src/app/models/train';
import { TrainService } from 'src/app/services/train.service';
@Component({
  selector: 'app-train-list',
  templateUrl: './train-list.component.html',
  styleUrls: ['./train-list.component.css']
})
export class TrainListComponent implements OnInit {
  trains: Train[] = [];
  constructor(private trainService: TrainService) {}
  ngOnInit(): void {
    this.loadTrains();
  }
  loadTrains() {
    this.trainService.getAllTrains().subscribe(data => this.trains = data);
  }

  deleteTrain(tno: number) {
    this.trainService.deleteTrain(tno).subscribe(() => this.loadTrains());
  }
}
