import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Train } from 'src/app/models/train';
import { TrainService } from 'src/app/services/train.service';

@Component({
  selector: 'app-train-update',
  templateUrl: './train-update.component.html',
  styleUrls: ['./train-update.component.css']
})
export class TrainUpdateComponent implements OnInit {

  trainId!: number;
  train: Train = {
    trainNumber: 0,
    trainName: '',
    trainPrice: 0,
    trainSource: '',
    trainDest: '',
    runningDays: [],
    trainStatus: 'RUNNING',
    route: { routeId: 0, routeName: '' }
  };

  constructor(
    private route: ActivatedRoute,
    private trainService: TrainService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.trainId = Number(this.route.snapshot.paramMap.get('id'));
    this.trainService.getTrainById(this.trainId).subscribe({
      next: (data) => this.train = data,
      error: (err) => alert('Error fetching train: ' + err.message)
    });
  }

  onUpdate() {
    this.trainService.updateTrain(this.trainId, this.train).subscribe({
      next: () => {
        alert('Train updated successfully');
        this.router.navigate(['/trains']); // Adjust route as per your app
      },
      error: err => alert('Error: ' + err.message)
    });
  }

}
