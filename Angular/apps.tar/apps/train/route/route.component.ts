import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'app-route',
  templateUrl: './route.component.html',
  styleUrls: ['./route.component.css']
})
export class RouteComponent {
  route = {
    routeId:'', 
    routeName: '' };
  stations = [
    { stationId:0,stationName: '', stationCity: '', stationState: '' }
  ];

  constructor(private http: HttpClient) {}

  addStation() {
    this.stations.push({stationId:0, stationName: '', stationCity: '', stationState: '' });
  }

  removeStation(index: number) {
    this.stations.splice(index, 1);
  }

  addRoute() {
    const routeData = {
      ...this.route,
      stations: this.stations
    };

    this.http.post('http://localhost:8080/api/route/add', routeData).subscribe(response => {
      console.log('Route added successfully', response);
      // Reset form
      this.route.routeName = '';
      this.stations = [{ stationId:0,stationName: '', stationCity: '', stationState: '' }];
    });
  }

}
