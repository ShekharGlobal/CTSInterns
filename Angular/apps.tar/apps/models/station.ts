import { Route } from "./train";

export interface Station {
    stationId: number;
    stationName: string;
    stationCity: string;
    stationState: string;
    route: Route
  }