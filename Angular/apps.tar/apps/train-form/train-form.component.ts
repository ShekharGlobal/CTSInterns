import { Component } from '@angular/core';
import { Train } from '../models/train';
import { TrainService } from '../services/train.service';
import { Route, Router } from '@angular/router';
@Component({
  selector: 'app-train-form',
  templateUrl: './train-form.component.html',
  styleUrls: ['./train-form.component.css']
})
export class TrainFormComponent {
  train: Train = {
    trainNumber: 0,
    trainName: '',
    trainPrice: 0,
    trainSource: '',
    trainDest: '',
    runningDays: [],
    trainStatus: 'RUNNING',
    route: { routeId: 0, routeName: '' }
  };

  constructor(private trainService: TrainService, private router:Router) {}

  onSubmit() {
    this.trainService.createTrain(this.train).subscribe({
      next: () => { alert('Train created successfully')
        this.router.navigate(['/trains']);
      },
      error: err => alert('Error: ' + err.message)
    });

  }
}
