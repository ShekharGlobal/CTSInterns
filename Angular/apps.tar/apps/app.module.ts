import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TrainListComponent } from './train/train-list/train-list.component';
import { TrainFormComponent } from './train-form/train-form.component';
import { TrainDetailsComponent } from './train/train-details/train-details.component';
import { RouteComponent } from './train/route/route.component';
import { TrainUpdateComponent } from './train/train-update/train-update.component';

@NgModule({
  declarations: [
    AppComponent,
    TrainListComponent,
    TrainFormComponent,
    TrainDetailsComponent,
    RouteComponent,
    TrainUpdateComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
