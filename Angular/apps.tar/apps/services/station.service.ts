import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Station } from '../models/station';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class StationService {
  private baseUrl = 'http://localhost:8080/api/station';

  constructor(private http: HttpClient) {}

  addStation(station: Station): Observable<Station> {
    return this.http.post<Station>(`${this.baseUrl}/add`, station);
  }
}
