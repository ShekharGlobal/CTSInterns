import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Route } from '../models/train';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class RouteService {
  private baseUrl = 'http://localhost:8080/api/route';
  constructor(private http: HttpClient) { }

  addRoute(route: Route): Observable<Route> {
    return this.http.post<Route>(`${this.baseUrl}/add`, route);
  }



}
