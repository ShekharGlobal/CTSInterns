package com.org.exception;

public class InvalidTrainNumber extends Exception {

	
	public InvalidTrainNumber(String errorMsg)
	{
		super(errorMsg);
	}
}
