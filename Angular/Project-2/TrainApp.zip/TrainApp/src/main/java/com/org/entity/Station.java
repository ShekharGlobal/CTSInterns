package com.org.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="train_station")
public class Station {

	@Id
	private long stationId;
	private String stationName;
	private String stationState;
	private String stationCity;
	@ManyToOne
	@JoinColumn(name="route_id")
    private Route route;
	public long getStationId() {
		return stationId;
	}
	public void setStationId(long stationId) {
		this.stationId = stationId;
	}
	public String getStationName() {
		return stationName;
	}
	public void setStationName(String stationName) {
		this.stationName = stationName;
	}
	public String getStationState() {
		return stationState;
	}
	public void setStationState(String stationState) {
		this.stationState = stationState;
	}
	public String getStationCity() {
		return stationCity;
	}
	public void setStationCity(String stationCity) {
		this.stationCity = stationCity;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
    
    
    
}
