package com.org.service;

import java.util.List;

import com.org.entity.Train;
import com.org.exception.InvalidTrainNumber;

public interface TrainService {
	
	public Train addTrain(Train train);
	public List<Train> viewAllTrain();
	public Train viewByNumber(long trainNum)throws InvalidTrainNumber;
	public List<Train> searchBySourceAndDest(String soure, String destination);
	public List<Train> searchByRoute(String routeName);
	public int updateTrain(long tno, Train newTrain);
	public  void removeTrain(long tno);
	

}
