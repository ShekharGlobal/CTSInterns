package com.org.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.entity.Train;
import com.org.exception.InvalidTrainNumber;
import com.org.repository.TrainRepository;
import com.org.service.TrainService;

@Service
public class TrainServiceImpl implements TrainService {

	@Autowired
	private TrainRepository trainRepos;
	@Override
	public Train addTrain(Train train) {
		// TODO Auto-generated method stub
		return trainRepos.save(train);
	}

	@Override
	public List<Train> viewAllTrain() {
		// TODO Auto-generated method stub
		return trainRepos.findAll();
	}

	@Override
	public Train viewByNumber(long trainNum) throws InvalidTrainNumber {
		if(trainRepos.existsById(trainNum))
{
		return trainRepos.findById(trainNum).get();
}else
	throw new InvalidTrainNumber("Invalid Train Number");
	}

	@Override
	public List<Train> searchBySourceAndDest(String soure, String destination) {
		// TODO Auto-generated method stub
		return trainRepos.findByTrainSourceAndTrainDest(soure, destination);
	}

	@Override
	public List<Train> searchByRoute(String routeName) {
		// TODO Auto-generated method stub
		return trainRepos.searchByRouteName(routeName);
	}

	@Override
	public int updateTrain(long tno, Train newTrain) {
		// TODO Auto-generated method stub
		return trainRepos.editTrain(newTrain.getTrainSource(), newTrain.getTrainDest(), newTrain.getTrainPrice(), tno);
	}

	@Override
	public void removeTrain(long tno) {
		// TODO Auto-generated method stub
 trainRepos.delete(trainRepos.findById(tno).get());
	
	}

}
