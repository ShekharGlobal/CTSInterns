package com.org;


import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.org.exception.InvalidTrainNumber;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	
	@ExceptionHandler(InvalidTrainNumber.class)
	public String handleInvalidId(InvalidTrainNumber e)
	{
		return e.getMessage();
	}

}
