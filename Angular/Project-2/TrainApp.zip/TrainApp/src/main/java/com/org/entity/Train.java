package com.org.entity;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
enum TrainStatus
{
	RUNNING,DIVERTED,CANCELLED
}


@Entity
@Table(name="Train_Table")

public class Train {
	@Id
	private long trainNumber;
	private String trainName;
	private double trainPrice;
	private String trainSource;
	private String trainDest;
	@ElementCollection
	private List<String> runningDays;
	@Enumerated(EnumType.STRING)
	private TrainStatus trainStatus;
	@ManyToOne
	@JoinColumn(name = "route_id")
	private Route route;
	public long getTrainNumber() {
		return trainNumber;
	}
	public void setTrainNumber(long trainNumber) {
		this.trainNumber = trainNumber;
	}
	public String getTrainName() {
		return trainName;
	}
	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}
	public double getTrainPrice() {
		return trainPrice;
	}
	public void setTrainPrice(double trainPrice) {
		this.trainPrice = trainPrice;
	}
	public List<String> getRunningDays() {
		return runningDays;
	}
	public void setRunningDays(List<String> runningDays) {
		this.runningDays = runningDays;
	}
	public TrainStatus getTrainStatus() {
		return trainStatus;
	}
	public void setTrainStatus(TrainStatus trainStatus) {
		this.trainStatus = trainStatus;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	public String getTrainSource() {
		return trainSource;
	}
	public void setTrainSource(String trainSource) {
		this.trainSource = trainSource;
	}
	public String getTrainDest() {
		return trainDest;
	}
	public void setTrainDest(String trainDest) {
		this.trainDest = trainDest;
	}
	

}
