package com.org.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.entity.Station;
import com.org.repository.StationRepository;

@RestController
@RequestMapping("/api/station")
@CrossOrigin("*")
public class StationController {

	@Autowired
	private StationRepository stationRepos;
	
	@PostMapping("/add")
	public Station addStation(@RequestBody Station station)
	{
		return stationRepos.save(station);
	}
	
	
}
