package com.org.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.org.entity.Train;

import jakarta.transaction.Transactional;

public interface TrainRepository  extends JpaRepository<Train, Long>{

public List<Train> findByTrainSourceAndTrainDest(String source, String destination);


@Query("select t from Train t where t.route.routeName=:r")
public List<Train> searchByRouteName(@Param("r")     String routeName);

@Transactional
@Modifying
@Query("update Train t set t.trainSource=?1,t.trainDest=?2,t.trainPrice=?3where t.trainNumber=?4")
public int editTrain(String source, String dest, double price,long tno);

}
