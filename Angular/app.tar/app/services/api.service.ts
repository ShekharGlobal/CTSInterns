import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:2040';

  constructor(private http: HttpClient) {}

  getUser(): Observable<string> {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('jwtToken')}`
    });
    return this.http.get<string>(`${this.baseUrl}/user`, { headers });
  }

  getAdmin(): Observable<string> {
    const headers = new HttpHeaders({
      Authorization: `Bearer ${localStorage.getItem('jwtToken')}`
    });
    console.log(headers);
    return this.http.get<string>(`${this.baseUrl}/admin`, { headers });
  }
}
