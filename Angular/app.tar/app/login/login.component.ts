import { Component } from '@angular/core';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent {
  username!: string;
  password!: string;

  constructor(private authService: AuthService, private router: Router) {}

  login() {
    this.authService.login({ username: this.username, password: this.password })
      .subscribe(token => {
        localStorage.setItem('jwtToken', token);
        //console.log(token);
        const role = this.authService.getUserRole();
        console.log(role);
        role == 'ROLE_ADMIN' ? this.router.navigate(['/admin']) : this.router.navigate(['/user']);
      });
  }
}
