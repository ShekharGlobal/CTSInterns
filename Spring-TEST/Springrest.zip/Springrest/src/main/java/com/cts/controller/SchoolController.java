package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.cts.dto.SchoolDTO;
import com.cts.dto.StudentDTO;
import com.cts.service.SchoolService;
@RestController
@RequestMapping("/school")
public class SchoolController {

    @Autowired
    private SchoolService schoolService;

    @PostMapping("/add")
    public ResponseEntity<String> addSchool(@RequestBody SchoolDTO schoolDTO) {

        schoolService.addSchool(schoolDTO);
        return ResponseEntity.ok("School Added");
    }

    @PostMapping("/register/{schoolId}")
    public ResponseEntity<String> registerStudents(@PathVariable Long schoolId,
                                                   @RequestBody List<StudentDTO> students) {

        schoolService.registerStudentToSchool(schoolId, students);
        return ResponseEntity.ok("Students Registered");
    }

    @GetMapping("/max/{city}")
    public List<SchoolDTO> getSchoolMaxStudents(@PathVariable String city){

        List<SchoolDTO> schools = schoolService.schoolWithMaximumStudents(city);

        for(SchoolDTO school : schools){

            Long id = school.getSchoolId();

            //This creates a dummy proxy object of SchoolController.
            // withSelfRel()-This represents the current resource itself
            Link selfLink = linkTo(methodOn(SchoolController.class)
                    .getSchoolMaxStudents(city)).withSelfRel();

            //linkTo() converts the method reference into a URL link.
           //withRel-This creates a custom relation name.
            Link registerStudentLink = linkTo(methodOn(SchoolController.class)
                    .registerStudents(id, null)).withRel("register-students");

            school.add(selfLink);
            school.add(registerStudentLink);
        }

        return schools;
    }
}