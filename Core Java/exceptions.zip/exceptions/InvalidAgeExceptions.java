package com.coforge.exceptions;
// Define the custom exception
public class InvalidAgeExceptions extends Exception {

   // private static final long serialVersionUID = 1L;

    // Constructor to pass the error message
    InvalidAgeExceptions(String message) {
        super(message);
    }
}

