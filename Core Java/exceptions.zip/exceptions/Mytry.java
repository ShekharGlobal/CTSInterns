package com.coforge.exceptions;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

//checked Exception
public class Mytry {

	public static void main(String[] args) {

		FileWriter fw =null;
		try {
			fw = new FileWriter("d:/july25.txt");
			fw.write("Welcome to all Participants");
			System.out.println("success");
		} catch (IOException f) {
			System.out.println("Exception");
		} finally {
			try {
				fw.close();
			} catch (IOException e) {
				System.out.println("Exception");
			}
		}

	}

}
