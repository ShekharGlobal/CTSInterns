package com.coforge.exceptions;
public class RethrowExample {
    public static void main(String[] args) {
        try {
            Mymethod();
        } catch (ArithmeticException e) {
            System.out.println("Exception caught in main: " + e.getMessage());
        }
    }

    static void Mymethod() throws ArithmeticException {
        try {
            // Code that throws an exception
            int result = 10 / 0; // This will throw ArithmeticException
        } catch (ArithmeticException e) {
            System.out.println("Exception caught in someMethod: " + e.getMessage());
            // Rethrow the exception
            throw e;
        }
    }
}
