package com.coforge.exceptions;

public class Demo {
	
	int dividend;
	int divisor;
	
	public int division() throws ArithmeticException{
		
		int result= dividend/divisor;
		return result;
		
		
	}

}
