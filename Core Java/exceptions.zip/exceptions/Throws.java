package com.coforge.exceptions;

public class Throws {
	
	public void div() {
		int x=10;
		int y=2;
		int z= x/y;
		
		System.out.println(z);
		throw new ArithmeticException();
		
	}

	public static void main(String[] args) {
		
		Throws t1= new Throws();
		
		try {
			t1.div();
		}
		catch(ArithmeticException e) {
			System.out.println("cannot divide by zero");
		}

	}

}
