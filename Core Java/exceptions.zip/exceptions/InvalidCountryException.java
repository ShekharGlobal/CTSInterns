package com.coforge.exceptions;
public class InvalidCountryException extends Exception {

    public InvalidCountryException(final String message) {
        super(message);
    }

    public InvalidCountryException(final Throwable exception) {
        super(exception);
    }

    public InvalidCountryException(final String message, final Throwable exception) {
        super(message, exception);
    }
}
