package com.coforge.exceptions;
public class AgeValidator {

    // Method to validate age
    public static void validateAge(int age) throws InvalidAgeExceptions {
        if (age < 0 || age > 150) {
            throw new InvalidAgeExceptions("Age is not valid: " + age);
        } else {
            System.out.println("Valid age: " + age);
        }
    }

    public static void main(String[] args) {
        try {
            // Test the validateAge method
            validateAge(200); // This will throw an exception
        } catch (InvalidAgeExceptions e) {
            // Catch the custom exception and print the error message
            System.out.println("Error: " + e.getMessage());
        }

        try {
            // Test with a valid age
            validateAge(25); // This will not throw an exception
        } catch (InvalidAgeExceptions e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
