package com.example.bridge;

interface TV {
	void on();

	void off();
}
