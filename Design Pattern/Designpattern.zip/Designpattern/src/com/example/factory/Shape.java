package com.example.factory;
interface Shape {
    void draw();
}
