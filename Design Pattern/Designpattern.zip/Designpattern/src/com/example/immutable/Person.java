package com.example.immutable;

public final class Person { // rule 1: class final
	private final String name; // rule 2: fields final
	private final int age;

	public Person(String name, int age) { // rule 4: set values in constructor
		this.name = name;
		this.age = age;
	}

	public String getName() { // rule 5: only getters
		return name;
	}

	public int getAge() {
		return age;
	}
}
