package com.example.immutable;

public class Main {
	public static void main(String[] args) {
		Person p = new Person("Ajay", 25);

		System.out.println(p.getName());
		System.out.println(p.getAge());
	}
}
