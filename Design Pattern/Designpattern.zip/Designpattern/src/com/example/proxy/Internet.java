package com.example.proxy;

interface Internet {
	void connectTo(String site);
}
