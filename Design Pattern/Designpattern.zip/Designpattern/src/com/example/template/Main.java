package com.example.template;
public class Main {
    public static void main(String[] args) {
        Game g1 = new Chess();
        g1.play();

        Game g2 = new Football();
        g2.play();
    }
}
