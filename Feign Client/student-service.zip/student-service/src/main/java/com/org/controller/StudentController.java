package com.org.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.org.config.CourseClient;
import com.org.dto.Course;
import com.org.dto.StudentResponse;
import com.org.entity.Student;
import com.org.repository.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentRepository repository;

    @Autowired
    private CourseClient courseClient;

    @PostMapping
    public Student saveStudent(@RequestBody Student student) {
        return repository.save(student);
    }

    @GetMapping("/{id}")
    public StudentResponse getStudent(@PathVariable Long id) {

        Student student = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        List<Course> courses = courseClient.getCoursesByIds(student.getCourseIds());

        StudentResponse response = new StudentResponse();
        response.setId(student.getId());
        response.setName(student.getName());
        response.setCourses(courses);

        return response;
    }

    @PostMapping("/{id}/courses")
    public Student addCoursesToStudent(@PathVariable Long id, @RequestBody List<Long> courseIds) {

        Student student = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Student not found"));

        if (student.getCourseIds() == null) {
            student.setCourseIds(new java.util.ArrayList<>());
        }

        student.getCourseIds().addAll(courseIds);

        Student savedStudent = repository.save(student);

        // ⭐ NEW: Update course-service also
        for (Long courseId : courseIds) {
            courseClient.addStudentToCourse(courseId, java.util.Set.of(id));
        }

        return savedStudent;
    }
}