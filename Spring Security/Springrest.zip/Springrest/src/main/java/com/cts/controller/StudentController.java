package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import com.cts.bean.Student;
import com.cts.repository.StudentRepository;

@RestController
@RequestMapping("/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // ✅ REGISTER (NO AUTH REQUIRED)
    @PostMapping("/register")
    public Student register(@RequestBody Student student) {

        // encode password
        student.setPassword(passwordEncoder.encode(student.getPassword()));

        // default role
        student.setRole("STUDENT");

        return studentRepository.save(student);
    }

    // ADMIN ONLY
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public List<Student> getAllStudents() {
        return studentRepository.findAll();
    }

    // STUDENT ONLY
    @GetMapping("/profile")
    @PreAuthorize("hasRole('STUDENT')")
    public String studentProfile() {
        return "Student profile accessed";
    }
}